<!DOCTYPE html>
<html lang="en">

<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;400;500;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/sobre.css"> <!-- Certifique-se de incluir seu arquivo CSS correto -->
    <title>Sobre nós</title>

    <!----swiper css------>
    <link rel="stylesheet" href="../CSS/swiper-bundle.min.css">
</head>

<body>
  <header> 

    
    <div class="logo">
        <img src="">
    </div>
    <input type="checkbox" id="nav_check" hidden>

  
    <?php

        
include_once("../PHP/conexao.php");

$count = "SELECT COUNT( cod_soli) AS total from solicitacao WHERE status_soli= 'Pendente'";

$qtd = $conexao->query($count);

if($qtd -> num_rows >0){

    $objeto = $qtd ->fetch_assoc();
    $totalNotifications = $objeto['total'];
}

$select = "SELECT DATE_FORMAT(solicitacao.data_soli, '%d/%m/%Y') AS data, cad_veiculos.marca_veiculo,cad_veiculos.modelo_veiculo 
           FROM solicitacao 
           INNER JOIN cad_veiculos 
           ON solicitacao.cod_veiculo = cad_veiculos.cod_veiculo 
           WHERE status_soli = 'Pendente'";

$detailsResult = $conexao->query($select);



echo '    <div class="notification center" id="notification">';

echo '        <input type="checkbox" name=""  id="notificacao" onclick="texto()">';

echo '        <div class="num number center">4</div>';

    echo '        <div class="box">';
    echo '            <div class="heading center">';
    echo '<p class="Pheading"> <span>' . $totalNotifications . '</span> Solicitações Pendentes</p>';
    echo '            </div>';
    echo '            <div class="notification_box">';

    if ($detailsResult->num_rows > 0) {
        while($row = $detailsResult->fetch_assoc()) {
            echo '<a href = "../PHP/responder.php">';
            echo '<p><i class="fas fa-circle green-dot"></i> Solicitação veículo: ' . htmlspecialchars($row['marca_veiculo']) . ' ' . htmlspecialchars($row['modelo_veiculo']) . ' - Data da solicitação: ' . htmlspecialchars($row['data']) . '</p>';
           echo'</a>';
        }
    } else {
        echo '<p>Não há solicitações pendentes.</p>';
    }
    echo '            </div>';
    echo '        </div>';

     echo '    </div>';


     
       
    
        ?>

  <script>
      const box = document.querySelectorAll('.notification_box p');
      const number = document.querySelectorAll('.number');

      number.forEach((e) => {
          e.innerText =box.length;
      });
  </script>

    
<script>
    function texto(){

        let notificacao = document.getElementById('notificacao');
        let text = document.getElementById('text-content');

        text.style.transition = 'opacity 0.5s ease-in-out';

        if (text.style.opacity === '0') {
        text.style.opacity = '1';
        } else {
        text.style.opacity = '0';
        }

    }

    function menuTexto(){

        let notificacao = document.getElementById('menu');
        let text = document.getElementById('text-content');
        let notification = document.getElementById('notification');

        text.style.transition = 'opacity 0.5s ease-in-out';

        if (notification.style.display === 'none' && text.style.opacity === '0') {
                notification.style.display = 'block';
                text.style.opacity = '1';
            } else {
                notification.style.display = 'none';
                text.style.opacity = '0';
            }
    }

</script>

    
    <nav class="navPrincipal">
        <div class="logo">
            <img src="logo.colocar" alt ="">
        </div>     

        <ul>
            <li><a class ="active" href="../HTML/index_seguradora.php">HOME </a></li>
            <li><a href="../HTML/login_eduarda.html"> Login  </a></li>
            <li><a href="../HTML/sobre.seguradora.php">  Sobre nós   </a></li>
           
            <li><a href="../PHP/responder.php">Responder Solicitações</a></li>     
           
        </ul>
    </nav>  


    <nav class="navMenu" >
        <div class="logo">
            <img src="logo.colocar" alt ="">
        </div>     

        <ul>
            <li><a class ="active" href="../HTML/index_seguradora.php">HOME </a></li>
            <li><a href="../HTML/login_eduarda.html"> Login  </a></li>
            <li><a href="../HTML/sobre.seguradora.php">  Sobre nós   </a></li>
            <li><a href="../HTML/carros.html">Cadastrar carros </a></li>
            <li><a href="../HTML/cadastrar_oficina.html">Cadastrar Seguradora/Oficina </a></li> 
            <li><a href="../PHP/deletar.php">Deletar Carros/Oficina</a></li> 
            <li><a href="../PHP/atualizar.php">Atualizar Carro/Oficina</a></li> 
            <li><a href="../PHP/responder.php">Responder Solicitações</a></li>     
           
        </ul>
    </nav> 

  


    <label for ="nav_check" class="hamburguer" id="menu" onclick="menuTexto()">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
    </label>
</header>  

<br>
<br> 
<br> 


    <section class="about" id="about">
        <div class="content">
          <div class="title-wrapper-about">
            <p>Sobre nós</p>
            <h3"></h3>
          </div>
          <div class="about-content">
            <div class="left">
              <img src="../IMG/about.png" alt="About" />
            </div>
            <div class="right">
              <h3>Tecnologia e Inovação</h3>
              <p>
                 Oferecemos uma gama completa de serviços,
                desde a instalação de sistemas de segurança avançados até a assistência em casos de emergência,
                proporcionando aos nossos clientes uma experiência de condução tranquila e segura.

                Nossa equipe altamente treinada está sempre pronta para agir, empregando tecnologias de ponta
                para antecipar e prevenir riscos. Além disso, cultivamos um relacionamento de confiança com
                nossos clientes, superando suas expectativas em cada interação e garantindo que cada viagem seja
                uma experiência positiva.

                Em parceria com seguradoras líderes do mercado, oferecemos soluções abrangentes que vão além da
                simples proteção dos veículos, incluindo cobertura para eventuais incidentes e um suporte
                excepcional ao cliente. Juntos, estamos comprometidos em proteger cada caminho, proporcionando
                segurança e tranquilidade a todos os nossos clientes.
              </p>
            </div>
          </div>
        </div>
      </section>
  
      <section class="features" id="features">
        <div class="content">
          <div class="title-wrapper-features">
            <p ">O que nós podemos fazer</p>
            <h3 "></h3>
          </div>
          <div class="feature-card-block">
            <div class="feature-card-item">
              <img src="../IMG/1.png" alt="Feature" />
              <div class="feature-text-content">             
                  <h3>Orçamentos de reparo:</h3>
                 
                <p> Avaliação e estimativa de custos para conserto de veículos danificados.</p>
              </div>
            </div>
            <div class="feature-card-item">
              <img src="../IMG/3.png" alt="Feature" />
              <div class="feature-text-content">
                <h3>Assistência 24 horas:</h3>
                <p>Suporte emergencial para problemas como pane mecânica, chave presa, entre outros.</p>
              </div>
            </div>
            <div class="feature-card-item">
              <img src="../IMG/9.png" alt="Feature" />
              <div class="feature-text-content">
                <h3>Atendimento ao cliente: </h3>
                <p>Esclarecimento de dúvidas, suporte técnico e acompanhamento do processo de sinistro.</p>
              </div>
            </div>
            <div class="feature-card-item">
              <img src="../IMG/3.png" alt="Feature" />
              <div class="feature-text-content">
                <h3>Cobertura de sinistros:</h3>
                <p>Compensação financeira por danos ao veículo ou terceiros em caso de acidente.</p>
              </div>
            </div>
            <div class="feature-card-item">
              <img src="../IMG/2.png" alt="Feature" />
              <div class="feature-text-content">
                <h3>Serviço de reboque:</h3>
                <p>Remoção do veículo para oficinas ou locais seguros em situações de emergência.</p>
              </div>
            </div>
            <div class="feature-card-item">
              <img src="../IMG/8.png" alt="Feature" />
              <div class="feature-text-content">
                <h3>Reparos e manutenção: </h3>
                <p>Oficinas parceiras para consertos e serviços regulares de manutenção do veículo.


                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
  
      <footer>
        <div class="main">
          <div class="content footer-links">
            <div class="footer-company">
              <h4>Company</h4>
              <h6>About</h6>
              <h6>Contact</h6>
            </div>
            <div class="footer-rental">
              <h4>Rental</h4>
              <h6>Self-Drive</h6>
              <h6>Chauffer-Driven</h6>
              <h6>Help</h6>
            </div>
            <div class="footer-social">
              <h4>Stay connected</h4>


              <div class="social-icons">
                <a href="https://www.facebook.com/share/qH82mrbGtN9YADyn/?mibextid=A7sQZp" target="_blank" rel="noopener noreferrer">
                  <img src="../IMG/facebook.png" alt="">
              </a>
       
                <a href="https://www.instagram.com/victor_rodriguees_?igsh=MWR3Nmt0bnZpbzN0ZA==" target="_blank" rel="noopener noreferrer">
                <img src="../IMG/instagran.png" alt="">
                  
  </a>
             <a href="https://x.com/Atletico?t=OAvR0zVHxKKmBzKDAaxZwA&s=09" target="_blank" rel="noopener noreferrer">
            <img src="../IMG/xtwitter.png" alt="">
        
</a>

              </div>
            </div>
            <div class="footer-contact">
              <h4>Contact US</h4>
              <h6>+55 31 988776655</h6>
              <h6>contato@devsuperior.com.br</h6>
              <h6>Nome da Rua, belo horizonte MG</h6>
            </div>
          </div>
        </div>
        <div class="last">DevSuperior 2021 - Use like you want</div>
      </footer>

</body>

</html>