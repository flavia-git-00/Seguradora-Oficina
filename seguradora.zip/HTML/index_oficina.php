<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;400;500;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="../CSS/style.css">
</head>
<body style="background-image: url('../IMG/fundo.png');">
    <header> 

    
        <div class="logo">
            <img src="">
        </div>
        <input type="checkbox" id="nav_check" hidden>

             <?php

        
include_once("../PHP/conexao.php");

$count = "SELECT COUNT( cod_res) AS total from resposta WHERE resposta= 'Aprovado'";

$qtd = $conexao->query($count);

if($qtd -> num_rows >0){

    $objeto = $qtd ->fetch_assoc();
    $totalNotifications = $objeto['total'];
}

$select = "SELECT DATE_FORMAT(resposta.data_res, '%d/%m/%Y') AS data, cad_veiculos.marca_veiculo,cad_veiculos.modelo_veiculo 
           FROM resposta
           INNER JOIN cad_veiculos 
           ON resposta.cod_veiculo = cad_veiculos.cod_veiculo 
           WHERE resposta = 'Aprovado'";

$detailsResult = $conexao->query($select);



echo '    <div class="notification center" id="notification">';

echo '        <input type="checkbox" name=""  id="notificacao" onclick="texto()">';

echo '        <div class="num number center">4</div>';

    echo '        <div class="box">';
    echo '            <div class="heading center">';
    echo '<p class="Pheading"> <span>' . $totalNotifications . '</span> Solicitações Aprovadas</p>';
    echo '            </div>';
    echo '            <div class="notification_box">';

    if ($detailsResult->num_rows > 0) {
        while($row = $detailsResult->fetch_assoc()) {
            echo '<a href = "../PHP/respondidas.php">';
            echo '<p><i class="fas fa-circle green-dot"></i> Solicitação aprovada: ' . htmlspecialchars($row['marca_veiculo']) . ' ' . htmlspecialchars($row['modelo_veiculo']) . ' - Data da resposta: ' . htmlspecialchars($row['data']) . '</p>';
           echo'</a>';
        }
    } else {
        echo '<p>Não há solicitações pendentes.</p>';
    }
    echo '            </div>';
    echo '        </div>';

        echo '    </div>';


     
       
    
        ?>
        
    <script>
        function texto(){

            let notificacao = document.getElementById('notificacao');
            let text = document.getElementById('text-content');

            text.style.transition = 'opacity 0.5s ease-in-out';

            if (text.style.opacity === '0') {
            text.style.opacity = '1';
            } else {
            text.style.opacity = '0';
            }
    
        }

        function menuTexto(){

            let notificacao = document.getElementById('menu');
            let text = document.getElementById('text-content');
            let notification = document.getElementById('notification');

            text.style.transition = 'opacity 0.5s ease-in-out';

            if (notification.style.display === 'none' && text.style.opacity === '0') {
                    notification.style.display = 'block';
                    text.style.opacity = '1';
                } else {
                    notification.style.display = 'none';
                    text.style.opacity = '0';
                }
        }

    </script>

        
        <nav class="navPrincipal">
            <div class="logo">
                <img src="logo.colocar" alt ="">
            </div>     
 
            <ul>
                <li><a class ="active" href="../HTML/index_oficina.php">HOME </a></li>
                <li><a href="../HTML/login_ofi.html"> Login  </a></li>
                <li><a href="../HTML/sobre.oficina.php">  Sobre nós   </a></li>
                <li><a href="../PHP/solicitacao.php">Solicitar Seguro</a></li>     
               
            </ul>
        </nav>  


        <nav class="navMenu" >
            <div class="logo">
                <img src="logo.colocar" alt ="">
            </div>     
 
            <ul>
                <li><a class ="active" href="../HTML/index_oficina.php">HOME </a></li>
                <li><a href="../HTML/login_ofi.html"> Login  </a></li>
                <li><a href="../HTML/sobre.oficina.php">  Sobre nós   </a></li>
                <li><a href="../PHP/cadfotos.php">Anexar Fotos </a></li>
                <li><a href="../PHP/orcamentoV.php">Orçamento </a></li> 
                <li><a href="../PHP/solicitacao.php">Solicitar Seguro</a></li> 
                <li><a href="../PHP/respondidas.php">Solicitações Respondidas</a></li> 
               
               
            </ul>
        </nav> 

      
      <script>
            const box = document.querySelectorAll('.notification_box p');
            const number = document.querySelectorAll('.number');
    
            number.forEach((e) => {
                e.innerText =box.length;
            });
        </script>
      

        <label for ="nav_check" class="hamburguer" id="menu" onclick="menuTexto()">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </label>
    </header>  
  
    <br>
    <br> 
    <br> 

    <section class="home" id="home">
        <div class="text-content" id="text-content">
            <h1>Solution Car</h1>
  <h3>
    A melhor proteção veicular <br> do Brasil.
    Sempre com você, <br> onde quer que você vá. ✈️
  </h3>
        </div>
    </section>

   

    <div id="image-container"></div>

    <script>
        // Array com os caminhos das imagens de fundo
        const images = [
            '../IMG/fundo.png',
            '../IMG/fundo5.png',
            '../IMG/fundo4.png',
            '../IMG/fundo4.png',
            '../IMG/fundo6.png',
            '../IMG/fundo2.png',
            // Adicione mais caminhos de imagem conforme necessário
        ];

        // Função para pré-carregar as imagens
        function preloadImages(urls) {
            urls.forEach(url => {
                const img = new Image();
                img.src = url;
                img.onload = () => {
                    console.log(`Imagem carregada: ${url}`);
                };
                img.onerror = (error) => {
                    console.error(`Erro ao carregar imagem: ${url}`, error);
                };
            });
        }

        // Pré-carrega as imagens
        preloadImages(images);

        // Índice atual da imagem de fundo
        let currentIndex = 0;

        // Função para alterar a imagem de fundo
        function changeBackgroundImage() {
            // Obtém o corpo do documento
            const body = document.body;

            // Altera a imagem de fundo usando o array de imagens
            body.style.backgroundImage = `url(${images[currentIndex]})`;

            // Incrementa o índice da imagem atual
            currentIndex = (currentIndex + 1) % images.length;
        }

        // Define o intervalo de tempo para alterar a imagem de fundo
        // Neste exemplo, a imagem muda a cada 3 segundos (3000 milissegundos)
        setInterval(changeBackgroundImage, 3000);
    </script>
</body>
</html>