

function atualizarImagem() {
    // Obter o valor selecionado
    var codigo_imagem = document.getElementById("codigo_imagem_chassi").value;
    console.log(codigo_imagem);
  
    // Enviar uma solicitação AJAX para buscar a imagem correspondente
    $.ajax({
      url: "buscar_imagem.php",
      type: "post",
      data: { codigo_imagem: codigo_imagem },
      success: function(data) {
        // Exibir a imagem retornada na div
        $("#imagem_chassi").html(data);
      },
      error: function() {
        alert("Erro ao buscar a imagem.");
      }
    });

 
  }

  //ENVIAR AJAX PARA BUSCAR IMAGEM DO HODOMETRO
  function atualizarImagemH(){

    var codigo_hodometro= document.getElementById("codigo_imagem_hodometro").value;
    console.log(codigo_hodometro);

    $.ajax({
      url: "buscar_imagem.php",
      type: "post",
      data: { codigo_hodometro: codigo_hodometro },
      success: function(data) {
        // Exibir a imagem retornada na div
        $("#imagem_hodometro").html(data);
      },
      error: function() {
        alert("Erro ao buscar a imagem.");
      }
    });

  }

  //UTILIZAR O AJAX PARA BUSCAR IMAGEM DA FRENTE DO CARRO

    function atualizarImagemF (){

      var codigo_frente= document.getElementById("cod_img_frente").value;
      console.log(codigo_frente);
  
      $.ajax({
        url: "buscar_imagem.php",
        type: "post",
        data: { codigo_frente: codigo_frente },
        success: function(data) {
          // Exibir a imagem retornada na div
          $("#imagem_frente").html(data);
        },
        error: function() {
          alert("Erro ao buscar a imagem.");
        }
      });

    }

    // ENVIAR AJAX PARA BUSCAR IMAGENS TRASEIRA

    function atualizarImagemT(){

      var codigo_traseira= document.getElementById("cod_img_traseira").value;
      console.log(codigo_traseira);
  
      $.ajax({
        url: "buscar_imagem.php",
        type: "post",
        data: { codigo_traseira: codigo_traseira },
        success: function(data) {
          // Exibir a imagem retornada na div
          $("#imagem_traseira").html(data);
        },
        error: function() {
          alert("Erro ao buscar a imagem.");
        }
      });

        
    }

  // ENVIAR AJAX PARA BUSCAR IMAGENS LATERAL DIREITA

    function atualizarImagemLD(){

      var codigo_latdireita= document.getElementById("cod_img_latdireita").value;
      console.log(codigo_latdireita);
  
      $.ajax({
        url: "buscar_imagem.php",
        type: "post",
        data: { codigo_latdireita: codigo_latdireita },
        success: function(data) {
          // Exibir a imagem retornada na div
          $("#imagem_latdireita").html(data);
        },
        error: function() {
          alert("Erro ao buscar a imagem.");
        }
      });
       
          
    }

    // ENVIAR AJAX PARA BUSCAR IMAGENS LATERAL ESQUERDA

    function atualizarImagemLE(){

      var codigo_latesquerda= document.getElementById("cod_img_latesquerda").value;
      console.log(codigo_latesquerda);
  
      $.ajax({
        url: "buscar_imagem.php",
        type: "post",
        data: { codigo_latesquerda: codigo_latesquerda },
        success: function(data) {
          // Exibir a imagem retornada na div
          $("#imagem_latesquerda").html(data);
        },
        error: function() {
          alert("Erro ao buscar a imagem.");
        }
      });
           
    }

    //ENVIAR AJAX PARA BUSCAR IMAGENS CAPO DO CARRO


    function atualizarImagemC (){

      var codigo_capo= document.getElementById("cod_img_capo").value;
      console.log(codigo_capo);
  
      $.ajax({
        url: "buscar_imagem.php",
        type: "post",
        data: { codigo_capo: codigo_capo },
        success: function(data) {
          // Exibir a imagem retornada na div
          $("#imagem_capo").html(data);
        },
        error: function() {
          alert("Erro ao buscar a imagem.");
        }
      });
           
    }

    //ENVIAR AJAX PARA BUSCAR IMAGENS DAS PEÇAS DO CARRO

    function atualizarImagemP (){

      var codigo_peca= document.getElementById("cod_img_pecas").value;
      console.log(codigo_peca);
  
      $.ajax({
        url: "buscar_imagem.php",
        type: "post",
        data: { codigo_peca: codigo_peca },
        success: function(data) {
          // Exibir a imagem retornada na div
          $("#imagem_pecas").html(data);
        },
        error: function() {
          alert("Erro ao buscar a imagem.");
        }
      });
           
    }






  