// CODIGO PARA EXIGIR NOME DE SEGURADORA MÍNIMO
 let nome_seg = document.querySelector('#nome_seg');
 let labelNomeSeg = document.querySelector('#labelNomeSeg');
 let requeridNome = /^[A-Za-z0-9 ]+$/;
 let nome_ofi = document.querySelector('#nome_ofi');
 let label_nome_ofi = document.querySelector('#label_nome_ofi');

    nome_seg.addEventListener('keyup', () => {
    console.log('Tecla liberada: ' + event.key);

    if (nome_seg.value.length ===0){
        labelNomeSeg.removeAttribute('style');
    }
    else if(!requeridNome.test(nome_seg.value) || nome_seg.value.length <=4 && nome_seg.value.length > 0){
        labelNomeSeg.setAttribute('style' ,'color:red');
       
    } 
    else{
        labelNomeSeg.setAttribute('style','color:green');
    }

});

nome_ofi.addEventListener('keyup', () => {
    console.log('Tecla liberada: ' + event.key);

    if (nome_ofi.value.length ===0){
        label_nome_ofi.removeAttribute('style');
    }
    else if(!requeridNome.test(nome_ofi.value) || nome_ofi.value.length <=4 && nome_ofi.value.length > 0){
        label_nome_ofi.setAttribute('style' ,'color:red');
       
    } 
    else{
        label_nome_ofi.setAttribute('style','color:green');
    }

});

//                   //                     //                  //


// CODIGO PARA EXIGIR NOME DE ADMINISTRADOR MÍNIMO
let adm_seg = document.querySelector('#adm_seg');
let label_adm_seg = document.querySelector('#label_adm_seg');
let requirid = /^[A-Za-z\s]+$/;
let nome_adm_ofi = document.querySelector('#nome_adm_ofi');
let label_adm_ofi = document.querySelector('#label_adm_ofi');

adm_seg.addEventListener('keyup', () => {
    console.log('Tecla liberada: ' + event.key);
    console.log('Comprimento do valor: ' + adm_seg.value.length); // Adicionando para diagnóstico

    if (adm_seg.value.length === 0) {
        label_adm_seg.setAttribute('style', ''); // Remove estilos aplicados
    } else if (!requirid.test(adm_seg.value) || adm_seg.value.length <= 4 && adm_seg.value.length >0) {
        label_adm_seg.setAttribute('style', 'color:red');
    } else {
        label_adm_seg.setAttribute('style', 'color:green');
    }
});


nome_adm_ofi.addEventListener('keyup', () => {
    console.log('Tecla liberada: ' + event.key);
    console.log('Comprimento do valor: ' + adm_seg.value.length); // Adicionando para diagnóstico

    if (nome_adm_ofi.value.length === 0) {
        label_adm_ofi.setAttribute('style', ''); // Remove estilos aplicados
    } else if (!requirid.test(nome_adm_ofi.value) || nome_adm_ofi.value.length <= 4 && nome_adm_ofi.value.length >0) {
        label_adm_ofi.setAttribute('style', 'color:red');
    } else {
        label_adm_ofi.setAttribute('style', 'color:green');
    }
});

//                   //                     //                  //


// CODIGO PARA EXIGIR NOME DE USUARIO MÍNIMO

 let requirid_user = /^(?=(?:.*[A-Za-z]){5,})(?=(?:.*\d){2,})[A-Za-z0-9\s\W_]+$/;
 let nome_user = document.querySelector('#nome_user');
 let label_user = document.querySelector('#label_user');

 nome_user.addEventListener('keyup',() =>{
    console.log('Tecla liberada: ' + event.key);
    if(nome_user.value.length ===0){
        label_user.removeAttribute('style');
        label_user.innerText ='Nome De Usuario';
     }else if(!requirid_user.test(nome_user.value) || nome_user.value.length <=4  && nome_user.value.length >0){
        label_user.setAttribute('style','color:red');
        label_user.innerText ='* Exigido 5 letras e 2 números ';
     }
     else{
        label_user.setAttribute('style','color:green')
     }
 });

 //                   //                     //                  //


 // CODIGO PARA EXIGIR SENHA MÍNIMA

 let senha_seg =document.querySelector('#senhaSeg');
 let label_senha_seg =document.querySelector('#label_senha_seg');
 let senha_ofi = document.querySelector('#senhaOfi');
 let label_senha_ofi= document.querySelector('#label_senha_ofi');

 senha_seg.addEventListener('keyup',() =>{
    if(senha_seg.value.length ===0){
        label_senha_seg.removeAttribute('style','');
        label_senha_seg.innerText ='Senha';
    }
    else if(senha_seg.value.length <=7 && senha_seg.value.length >0){
        label_senha_seg.setAttribute('style','color:red');
        label_senha_seg.innerText ='* Senha mínima 8 caracteres';
    }else{
        label_senha_seg.setAttribute('style','color:green')
    }
 })


 senha_ofi.addEventListener('keyup',() =>{
    if(senha_ofi.value.length ===0){
        label_senha_ofi.removeAttribute('style','');
        label_senha_ofi.innerText ='Senha';
    }
    else if(senha_ofi.value.length <=7 && senha_ofi.value.length >0){
        label_senha_ofi.setAttribute('style','color:red');
        label_senha_ofi.innerText ='* Senha mínima 8 caracteres';
    }else{
        label_senha_ofi.setAttribute('style','color:green')
    }
 })




 //                   //                     //                  //


  // CODIGO PARA EXIGIR CONFIRMAÇÃO DE SENHA IGUAIS

 let confirmar_senha_seg = document.querySelector('#confirmsenhaSeg');
 let label_confirm_seg = document.querySelector('#label_confirm');
 let confirm_senha_ofi = document.querySelector('#confirmsenhaOfi');
 let label_confirm_ofi = document.querySelector('#label_confirm_ofi');

 confirmar_senha_seg.addEventListener('keyup',() =>{
    if(confirmar_senha_seg.value.length ===0){
        label_confirm_seg.removeAttribute('style','');
       
    }
  else if(confirmar_senha_seg.value != senha_seg.value){
        label_confirm_seg.setAttribute('style','color:red');
    }else{
        label_confirm_seg.setAttribute('style','color:green')
    }  
  })


  confirm_senha_ofi.addEventListener('keyup',() =>{
    if(confirm_senha_ofi.value.length ===0){
        label_confirm_ofi.removeAttribute('style','');
       
    }
  else if(confirm_senha_ofi.value != senha_ofi.value){
        label_confirm_ofi.setAttribute('style','color:red');
    }else{
        label_confirm_ofi.setAttribute('style','color:green')
    }  
  })

 //                   //                     //                  //

 let email = document.querySelector('#email');
 let label_email = document.querySelector('#label_email');
 let required_email = /^[A-Za-z0-9_]{3,}@(?:gmail|hotmail)\.com$/;
 
 email.addEventListener('keyup', () => {
     if (email.value.trim() === '') {
         label_email.removeAttribute('style');
     } else if (!required_email.test(email.value)) {
         label_email.style.color = 'red';
     } else {
         label_email.style.color = 'green';
     }
 });
 

 const cnpjInput = document.getElementById('cnpj');
 const label_cnpj = document.getElementById('label_cnpj');

 cnpjInput.addEventListener('keyup', () => {
    if (cnpjInput.value.trim() === '') {
        label_cnpj.removeAttribute('style');
    } else if (cnpjInput.value.length <=17 && cnpjInput.value.length >0) {
        label_cnpj.style.color = 'red';
    } else {
        label_cnpj.style.color = 'green';
    }
});

 cnpjInput.addEventListener('input', (event) => {

     let inputValue = event.target.value.replace(/\D/g, ''); // Remove todos os caracteres que não são dígitos
     inputValue = inputValue.substring(0, 14); // Limita a 14 caracteres

     inputValue = inputValue.replace(/^(\d{2})(\d)/, '$1.$2'); // Adiciona o primeiro ponto
     inputValue = inputValue.replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3'); // Adiciona o segundo ponto
     inputValue = inputValue.replace(/\.(\d{3})(\d)/, '.$1/$2'); // Adiciona a barra
     inputValue = inputValue.replace(/(\d{4})(\d)/, '$1-$2'); // Adiciona o traço

     event.target.value = inputValue;
 });





        const telefoneInput = document.getElementById('telefone');
        const label_telefone= document.getElementById('label_telefone');

        telefoneInput.addEventListener('keyup', () => {
            if (telefoneInput.value.trim() === '') {
                label_telefone.removeAttribute('style');
            } else if (telefoneInput.value.length <=14 && telefoneInput.value.length >0) {
                label_telefone.style.color = 'red';
            } else {
                label_telefone.style.color = 'green';
            }
        });




        telefoneInput.addEventListener('input', (event) => {
            let inputValue = event.target.value.replace(/\D/g, ''); // Remove todos os caracteres que não são dígitos
            inputValue = inputValue.substring(0, 11); // Limita a 11 caracteres

            inputValue = inputValue.replace(/^(\d{2})(\d)/, '($1) $2'); // Adiciona o código de área
            inputValue = inputValue.replace(/(\d{5})(\d)/, '$1-$2'); // Adiciona o traço

            event.target.value = inputValue;
        });