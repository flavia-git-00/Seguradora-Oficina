document.addEventListener('DOMContentLoaded', (event) => {
    const notificationIcon = document.getElementById('notification-icon');
    const notificationPopup = document.getElementById('notification-popup');
    const closePopup = document.getElementById('close-popup');

    notificationIcon.addEventListener('click', (event) => {
        event.preventDefault();
        notificationPopup.classList.toggle('hidden');
    });

    closePopup.addEventListener('click', () => {
        notificationPopup.classList.add('hidden');
    });

    // Opcional: Fechar a janela de notificações ao clicar fora dela
    window.addEventListener('click', (event) => {
        if (event.target !== notificationIcon && !notificationPopup.contains(event.target)) {
            notificationPopup.classList.add('hidden');
        }
    });
});
