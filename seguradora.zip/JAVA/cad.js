



let btn = document.querySelector('#verSenha')
let btnConfirm = document.querySelector('#verConfirmSenha')


let nome = document.querySelector('#nome')
let labelNome = document.querySelector('#labelNome')
let validNome = false

let usuario = document.querySelector('#usuario')
let labelUsuario = document.querySelector('#labelUsuario')
let validUsuario = false

let senha = document.querySelector('#senha')
let labelSenha = document.querySelector('#labelSenha')
let validSenha = false

let confirmSenha = document.querySelector('#confirmSenha')
let labelConfirmSenha = document.querySelector('#labelConfirmSenha')
let validConfirmSenha = false

let msgError = document.querySelector('#msgError')
let msgSuccess = document.querySelector('#msgSuccess')

// Adicionando evento de keyup para o campo de nome
nome.addEventListener('keyup', () => {
  if (nome.value.length <= 2) {
    setError(labelNome, 'Nome *Insira no mínimo 3 caracteres');
    validNome = false;
  } else {
    setSuccess(labelNome, 'Nome');
    validNome = true;
  }
});

// Adicionando evento de keyup para o campo de usuário
usuario.addEventListener('keyup', () => {
  if (usuario.value.length <= 4) {
    setError(labelUsuario, 'Usuário *Insira no mínimo 5 caracteres');
    validUsuario = false;
  } else {
    setSuccess(labelUsuario, 'Usuário');
    validUsuario = true;
  }
});

// Adicionando evento de keyup para o campo de senha
senha.addEventListener('keyup', () => {
  if (senha.value.length <= 5) {
    setError(labelSenha, 'Senha *Insira no mínimo 6 caracteres');
    validSenha = false;
  } else {
    setSuccess(labelSenha, 'Senha');
    validSenha = true;
  }
});

// Adicionando evento de keyup para o campo de confirmação de senha
confirmSenha.addEventListener('keyup', () => {
  if (senha.value != confirmSenha.value) {
    setError(labelConfirmSenha, 'Confirmar Senha *As senhas não conferem');
    validConfirmSenha = false;
  } else {
    setSuccess(labelConfirmSenha, 'Confirmar Senha');
    validConfirmSenha = true;
  }
});

// Função para configurar um campo como erro
function setError(element, message) {
  element.style.color = 'red';
  element.innerHTML = message;
  element.previousElementSibling.style.borderColor = 'red';
}

// Função para configurar um campo como sucesso
function setSuccess(element, message) {
  element.style.color = 'green';
  element.innerHTML = message;
  element.previousElementSibling.style.borderColor = 'green';
}

// Função para realizar o cadastro
function cadastrar() {
  if (validNome && validUsuario && validSenha && validConfirmSenha) {
    let listaUser = JSON.parse(localStorage.getItem('listaUser') || '[]');
    listaUser.push({
      nomeCad: nome.value,
      userCad: usuario.value,
      senhaCad: senha.value
    });
    localStorage.setItem('listaUser', JSON.stringify(listaUser));
    showMessage(msgSuccess, 'Cadastrando usuário...');
    hideMessage(msgError);
    setTimeout(() => {
      window.location.href = '../HTML/entraratualizado.html';
    }, 3000);
  } else {
    showMessage(msgError, 'Preencha todos os campos corretamente antes de cadastrar');
    hideMessage(msgSuccess);
  }
}

// Event listener para o botão de mostrar/ocultar senha
btn.addEventListener('click', () => {
  togglePasswordVisibility('senha');
});

// Event listener para o botão de mostrar/ocultar confirmação de senha
btnConfirm.addEventListener('click', () => {
  togglePasswordVisibility('confirmSenha');
});

// Função para alternar a visibilidade da senha
function togglePasswordVisibility(id) {
  let inputSenha = document.querySelector(`#${id}`);
  if (inputSenha.getAttribute('type') === 'password') {
    inputSenha.setAttribute('type', 'text');
  } else {
    inputSenha.setAttribute('type', 'password');
  }
}

// Função para exibir uma mensagem
function showMessage(element, message) {
  element.style.display = 'block';
  element.innerHTML = `<strong>${message}</strong>`;
}

// Função para esconder uma mensagem
function hideMessage(element) {
  element.style.display = 'none';
}