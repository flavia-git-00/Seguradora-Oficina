function exibirImagem(event) {
    var input = event.target;
    var reader = new FileReader();
    reader.onload = function(){
        var dataURL = reader.result;
        var output = document.getElementById('imgtraseira');
        output.src = dataURL;
    };
    reader.readAsDataURL(input.files[0]);
}

function exibirImagemF(event) {
    var input = event.target;
    var reader = new FileReader();
    reader.onload = function(){
        var dataURL = reader.result;
        var output = document.getElementById('imgfrente');
        output.src = dataURL;
    };
    reader.readAsDataURL(input.files[0]);
}

function exibirImagemLE(event) {
    var input = event.target;
    var reader = new FileReader();
    reader.onload = function(){
        var dataURL = reader.result;
        var output = document.getElementById('imgesquerda');
        output.src = dataURL;
    };
    reader.readAsDataURL(input.files[0]);
}

function exibirImagemLD(event) {
    var input = event.target;
    var reader = new FileReader();
    reader.onload = function(){
        var dataURL = reader.result;
        var output = document.getElementById('imgdireita');
        output.src = dataURL;
    };
    reader.readAsDataURL(input.files[0]);
}

function exibirImagemCH(event) {
    var input = event.target;
    var reader = new FileReader();
    reader.onload = function(){
        var dataURL = reader.result;
        var output = document.getElementById('imgchassi');
        output.src = dataURL;
    };
    reader.readAsDataURL(input.files[0]);
}

function exibirImagemH(event) {
    var input = event.target;
    var reader = new FileReader();
    reader.onload = function(){
        var dataURL = reader.result;
        var output = document.getElementById('imghodometro');
        output.src = dataURL;
    };
    reader.readAsDataURL(input.files[0]);
}

function exibirImagemC(event) {
    var input = event.target;
    var reader = new FileReader();
    reader.onload = function(){
        var dataURL = reader.result;
        var output = document.getElementById('imgcapo');
        output.src = dataURL;
    };
    reader.readAsDataURL(input.files[0]);
}

function exibirImagemP(event) {
    var input = event.target;
    var reader = new FileReader();
    reader.onload = function(){
        var dataURL = reader.result;
        var output = document.getElementById('imgpecas');
        output.src = dataURL;
    };
    reader.readAsDataURL(input.files[0]);
}