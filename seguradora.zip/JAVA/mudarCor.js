function changeColor() {
    const linha = document.getElementById("linha");

    linha.style.backgroundColor = "#FF0000";
}
