<?php
// Conectar ao banco de dados
include_once('conexao.php');

// Verificar se o código da imagem foi recebido
if(isset($_POST['codigo_imagem'])) {


  // Obter o código da imagem
  $codigo_imagem = $_POST['codigo_imagem'];

  // Consultar o banco de dados para obter a imagem correspondente
  $consulta_imagem = mysqli_query($conexao, "SELECT imagem FROM imagens WHERE cod_imagem = '$codigo_imagem'");
  $resultado_imagem = mysqli_fetch_array($consulta_imagem);
  $imagem = $resultado_imagem['imagem'];
 
  // Exibir a imagem
  echo '<img src="data:image/jpeg;base64,'.base64_encode($imagem).'">';


}

//BUSCAR A IMAGEM DO BANCO IMAGENS HODOMETRO

if(isset($_POST['codigo_hodometro'])) {
  // Obter o código da imagem
  $codigo_hodometro = $_POST['codigo_hodometro'];

  // Consultar o banco de dados para obter a imagem correspondente
  $consulta_imagem_hodometro = mysqli_query($conexao, "SELECT imagem_hodometro FROM imagens_hodometro WHERE cod_imagem_hodometro = '$codigo_hodometro'");
  $resultado_imagem_hodometro = mysqli_fetch_array($consulta_imagem_hodometro);
  $imagemH = $resultado_imagem_hodometro['imagem_hodometro'];

  // Exibir a imagem
  echo '<img src="data:image/jpeg;base64,'.base64_encode($imagemH).'">';
  
}

  //BUSCAR IMAGENS FRENTE DO VEICULO

  if(isset($_POST['codigo_frente'])) {
    // Obter o código da imagem
    $codigo_frente = $_POST['codigo_frente'];
  
    // Consultar o banco de dados para obter a imagem correspondente
    $consulta_imagem_frente = mysqli_query($conexao, "SELECT imagem_frente FROM imagens_frente WHERE cod_imagem_frente = '$codigo_frente'");
    $resultado_imagem_frente = mysqli_fetch_array($consulta_imagem_frente);
    $imagemF = $resultado_imagem_frente['imagem_frente'];
  
    // Exibir a imagem
    echo '<img src="data:image/jpeg;base64,'.base64_encode($imagemF).'">';
    
  }

  //BUSCAR IMAGENS TRASEIRA DO CARRO


  if(isset($_POST['codigo_traseira'])) {
    // Obter o código da imagem
    $codigo_traseira = $_POST['codigo_traseira'];
  
    // Consultar o banco de dados para obter a imagem correspondente
    $consulta_imagem_traseira = mysqli_query($conexao, "SELECT imagem_traseira FROM imagens_traseira WHERE cod_imagem_traseira = '$codigo_traseira'");
    $resultado_imagem_traseira = mysqli_fetch_array($consulta_imagem_traseira);
    $imagemT = $resultado_imagem_traseira['imagem_traseira'];
  
    // Exibir a imagem
    echo '<img src="data:image/jpeg;base64,'.base64_encode($imagemT).'">';
    
  }

  //BUSCAR IMAGENS LATERAL DIREITA DO CARRO

  if(isset($_POST['codigo_latdireita'])) {
    // Obter o código da imagem
    $codigo_latdireita = $_POST['codigo_latdireita'];
  
    // Consultar o banco de dados para obter a imagem correspondente
    $consulta_imagem_latdireita = mysqli_query($conexao, "SELECT imagem_latdireita FROM imagens_latdireita WHERE cod_imagem_latdireita = '$codigo_latdireita'");
    $resultado_imagem_latdireita = mysqli_fetch_array($consulta_imagem_latdireita);
    $imagemLD = $resultado_imagem_latdireita['imagem_latdireita'];
  
    // Exibir a imagem
    echo '<img src="data:image/jpeg;base64,'.base64_encode($imagemLD).'">';
    
  }

  //BUSCAR IMAGENS LATERAL ESQUERDA DO CARRO

  if(isset($_POST['codigo_latesquerda'])) {
    // Obter o código da imagem
    $codigo_latesquerda = $_POST['codigo_latesquerda'];
  
    // Consultar o banco de dados para obter a imagem correspondente
    $consulta_imagem_latesquerda = mysqli_query($conexao, "SELECT imagem_latesquerda FROM imagens_latesquerda WHERE cod_imagem_latesquerda = '$codigo_latesquerda'");
    $resultado_imagem_latesquerda = mysqli_fetch_array($consulta_imagem_latesquerda);
    $imagemLE = $resultado_imagem_latesquerda['imagem_latesquerda'];
  
    // Exibir a imagem
    echo '<img src="data:image/jpeg;base64,'.base64_encode($imagemLE).'">';
    
  }

  //BUSCAR IMAGENS CAPO DO CARRO

  
  if(isset($_POST['codigo_capo'])) {
    // Obter o código da imagem
    $codigo_capo = $_POST['codigo_capo'];
  
    // Consultar o banco de dados para obter a imagem correspondente
    $consulta_imagem_capo = mysqli_query($conexao, "SELECT imagem_capo FROM imagens_capo WHERE cod_imagem_capo = '$codigo_capo'");
    $resultado_imagem_capo = mysqli_fetch_array($consulta_imagem_capo);
    $imagemC = $resultado_imagem_capo['imagem_capo'];
  
    // Exibir a imagem
    echo '<img src="data:image/jpeg;base64,'.base64_encode($imagemC).'">';
    
  }

  //BUSCAR IMAGENS DAS PEÇAS DO CARRO

  if(isset($_POST['codigo_peca'])) {
    // Obter o código da imagem
    $codigo_peca = $_POST['codigo_peca'];
  
    // Consultar o banco de dados para obter a imagem correspondente
    $consulta_imagem_peca = mysqli_query($conexao, "SELECT imagem_pecas FROM imagens_pecas WHERE cod_imagem_pecas = '$codigo_peca'");
    $resultado_imagem_peca = mysqli_fetch_array($consulta_imagem_peca);
    $imagemP = $resultado_imagem_peca['imagem_pecas'];
  
    // Exibir a imagem
    echo '<img src="data:image/jpeg;base64,'.base64_encode($imagemP).'">';
    
  }







?>
