<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <title>Carrossel de Login</title>
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            background-image: linear-gradient(to right, rgb(30, 20, 32),#551252);
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #ffffff; /* Adicionado para cor padrão do texto */
        }

        .icons {
            position: absolute;
            top: 10px;
            left: 10px;
            color: #ffffff;
            text-decoration: none;
            font-size: 40px;
            cursor: pointer;
        }

        .bi-arrow-return-left {
            color: #ffffff;
        }

        .box {
            color: #ffffff; /* Cor do texto dentro da caixa */
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color:  #f5ededa1;
            width: 20%;
            padding: 34px;
            border-radius: 4%;
            box-shadow: 3px 3px 1px 0px #292929b0;
            text-align: center; /* Centralizando o conteúdo */
        }

        fieldset {
            border: 3px solid #1e081d;
        }

        legend {
            border: 1px solid #240723;
            padding: 10px;
            text-align: center;
            background-color:#2f0c2d;
            border-radius: 8px;
        }

        .inputBox {
            position: relative;
            margin-bottom: 20px;
        }

        .inputUser {
            background: none;
            border: none;
            border-bottom: 1px solid rgb(30, 9, 31);
            outline: none;
            color: rgb(0, 0, 0);
            font-size: 15px;
            width: 100%;
            letter-spacing: 2px;
            transition: all 0.3s ease-out;
        }

        .labelInput {
            position: absolute;
            top: 0px;
            left: 0px;
            pointer-events: none;
            transition: all 0.3s ease-out;
            color: #761f75;
        }

        .inputUser:focus ~ .labelInput,
        .inputUser:not(:placeholder-shown) ~ .labelInput {
            top: -20px;
            font-size: 12px;
            color: #761f75;
        }

        #submit {
            background-image: linear-gradient(to right,#591758, #1e081d);
            width: 100%;
            border: none;
            padding: 15px;
            color: white;
            font-size: 15px;
            cursor: pointer;
            border-radius: 10px;
        }

        #submit:hover {
            background-image: linear-gradient(to right,#1e081d, #591758);
        }

        .carousel-button {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            padding: 10px;
            background-color: rgba(0, 0, 0, 0.5);
            color: #fff;
            border: none;
            border-radius: 50%;
            z-index: 100;
            transition: background-color 0.3s ease;
        }

        .prev {
            left: 10px;
        }

        .next {
            right: 10px;
        }

        .carousel-button:hover {
            background-color: rgba(0, 0, 0, 0.7);
        }

        .submit-link {
            text-decoration: none;
            
        }

        .slide {
    opacity: 0;
    transition: opacity 0.5s ease-in-out;
}

.slide.active {
    opacity: 1;
}

    </style>
</head>
<body>

<div class="icons">
    <a href="../HTML/index_seguradora.php" class="back-button"><i class="bi bi-arrow-return-left"></i></a>
</div>

<div class="carousel-container">
    <div class="carousel">
        <div class="box">
            <form action="../PHP/atualizar_car.php" method="post">
                <fieldset>
                    <legend><b> Atualizar Carro</b></legend>
    
                    <br>
                    <div class="inputBox">
                    <select name="select" class="inputUser" required> 
                    <?php
                    include_once('conexao.php');
                    $consulta = mysqli_query($conexao, "SELECT cod_veiculo as codigo, marca_veiculo as Marca FROM cad_veiculos");

                    while ($resultado = mysqli_fetch_array($consulta)) {
                        echo "<option value='" . $resultado['codigo'] . "'>" . $resultado['Marca'] ."</option>";
                    }
                    ?>
                    </select>
                    <label class="labelInput"> MARCA: </label>
                </div>
                     <br>
                     <div class="inputBox">
                    <select name="select2" class="inputUser" required>
                    <?php
                    $consulta2 = mysqli_query($conexao, "SELECT cod_veiculo as Cod, modelo_veiculo as Modelo FROM cad_veiculos");

                    while ($resultado2 = mysqli_fetch_array($consulta2)){
                        echo "<option value='" . $resultado2['Cod'] . "'>" . $resultado2['Modelo'] ."</option>";
                    }
                    ?>
                    </select>
                    <label class="labelInput"> MODELO: </label>
                </div>
                    <br>

                    <div class="inputBox">
                        <select name="select3" class="inputUser" required>
                        <?php
                            $consulta3 = mysqli_query($conexao, "SELECT cod_veiculo as Cod2, placa_veiculo as Placa FROM cad_veiculos");

                            while ($resultado3 = mysqli_fetch_array($consulta3)){
                            echo "<option value='" .$resultado3['Cod2'] ."'>" . $resultado3['Placa'] . "</option>";
                            }
                        ?>
                        </select>
                        <label class="labelInput"> PLACA: </label>
                        </div>
               <br><br>
                 <br>
    
        
                <input type="submit" id="submit" value="SELECIONAR">
    
                </fieldset>
            </form>
        </div>

        <div class="box">
            <form action="../PHP/atualizar_ofi.php" method="post">
                <fieldset>
                    <legend><b>Atualizar Oficina </b></legend>
    
                    <br>
                    
                    <div class="inputBox">
                    <select name="select" class="inputUser"> 
                    <?php
                        $consulta = mysqli_query($conexao, "SELECT cod_usuario_oficina as codigo, cad_nome as nome FROM cad_oficina");

                        while ($resultado = mysqli_fetch_array($consulta)) {
                        echo "<option value='" . $resultado['codigo'] . "'>" . $resultado['nome'] ."</option>";
                        }
                    ?>
                    </select> 
                
                    <label class="labelInput"> Oficina: </label>
                    </div>
    
               <br><br>

                <input type="submit" id="submit" value="SELECIONAR">
    
                </fieldset>
            </form>
        </div>

    </div>
    <button class="carousel-button prev" onclick="moveCarousel(-100)">&#10094;</button>
    <button class="carousel-button next" onclick="moveCarousel(100)">&#10095;</button>
</div>

<script>
    var slideIndex = 0;
    showSlides(slideIndex);

    function moveCarousel(n) {
        showSlides(slideIndex += n);
    }

    function showSlides(n) {
        var i;
        var slides = document.getElementsByClassName("box");
        if (n >= slides.length) { slideIndex = 0 }
        if (n < 0) { slideIndex = slides.length - 1 }
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        slides[slideIndex].style.display = "block";




        
    }
</script>

</body>
</html>
