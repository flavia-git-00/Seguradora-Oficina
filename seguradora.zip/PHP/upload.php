<?php

include_once("conexao.php");




     $imagem = $_FILES['arquivo']['tmp_name'];
     $tamanho = $_FILES['arquivo']['size'];
     $tipo = $_FILES['arquivo']['type'];
     $nome = $_FILES['arquivo']['name'];
     $select = $_POST['codigo_veiculo'];
  

    if($imagem != "none"){
    $fp = fopen($imagem,"rb");
    $conteudo = fread($fp,$tamanho);
    $conteudo = addslashes($conteudo);
    fclose($fp);

    } 
  

    $inserir = "INSERT INTO imagens (cod_veiculo, nome_imagem, tipo_imagem, tamanho_imagem, imagem)
    SELECT '$select', '$nome', '$tipo', '$tamanho', '$conteudo'
    FROM cad_veiculos
    WHERE cad_veiculos.cod_veiculo = '$select'";



             mysqli_query($conexao,$inserir) or die ("ALGO DEU ERRADO NA INSERÇÃO!!");

             

             //INSERIR IMAGENS NA BASE DE DADOS DO HODOMETRO

             $imagemH = $_FILES['arquivoH']['tmp_name'];
             $tamanhoH = $_FILES['arquivoH']['size'];
             $tipoH = $_FILES['arquivoH']['type'];
             $nomeH= $_FILES['arquivoH']['name'];
             $selectH = $_POST['codigo_veiculo_H'];

             if($imagemH != "none"){
               $fpH = fopen($imagemH,"rb");
               $conteudoH = fread($fpH,$tamanhoH);
               $conteudoH = addslashes($conteudoH);
               fclose($fpH);
              } 
            
             
             $inserirH = "INSERT INTO imagens_hodometro (cod_veiculo, nome_imagem_hodometro, tipo_imagem_hodometro, tamanho_imagem_hodometro, imagem_hodometro)
             SELECT '$selectH', '$nomeH', '$tipoH', '$tamanhoH', '$conteudoH'
             FROM cad_veiculos
             WHERE cad_veiculos.cod_veiculo = '$selectH'";

             mysqli_query($conexao,$inserirH) or die ("ALGO DEU ERRADO NA IMAGEM 2!");
          

             //INSERIR IMAGENS NA BASE DE DADOS DO FRENTE DO CARRO

             $imagemF = $_FILES['arquivoF']['tmp_name'];
             $tamanhoF = $_FILES['arquivoF']['size'];
             $tipoF = $_FILES['arquivoF']['type'];
             $nomeF= $_FILES['arquivoF']['name'];
             $selectF = $_POST['codigo_veiculo_F'];

             
             if($imagemF != "none"){
              $fpF = fopen($imagemF,"rb");
              $conteudoF = fread($fpF,$tamanhoF);
              $conteudoF = addslashes($conteudoF);
              fclose($fpF);
             }

          

             $inserirF = "INSERT INTO imagens_frente (cod_veiculo, nome_imagem_frente, tipo_imagem_frente, tamanho_imagem_frente, imagem_frente)
             SELECT '$selectF', '$nomeF', '$tipoF', '$tamanhoF', '$conteudoF'
             FROM cad_veiculos
             WHERE cad_veiculos.cod_veiculo = '$selectH'";

             mysqli_query($conexao,$inserirF) or die ("ALGO DEU ERRADO NA IMAGEM 2!");
            

            //INSERIR IMAGENS NA BASE DE DADOS DO TRASEIRA DO CARRO
  
              $imagemT = $_FILES['arquivoT']['tmp_name'];
              $tamanhoT = $_FILES['arquivoT']['size'];
              $tipoT = $_FILES['arquivoT']['type'];
              $nomeT= $_FILES['arquivoT']['name'];
              $selectT = $_POST['codigo_veiculo_T'];

            if($imagemF != "none"){
              $fpT = fopen($imagemT,"rb");
              $conteudoT = fread($fpT,$tamanhoT);
              $conteudoT = addslashes($conteudoT);
              fclose($fpT);
             }

             $inserirT = "INSERT INTO imagens_traseira (cod_veiculo, nome_imagem_traseira, tipo_imagem_traseira, tamanho_imagem_traseira, imagem_traseira)
             SELECT '$selectT', '$nomeT', '$tipoT', '$tamanhoT', '$conteudoT'
             FROM cad_veiculos
             WHERE cad_veiculos.cod_veiculo = '$selectT'";

             mysqli_query($conexao,$inserirT) or die ("ALGO DEU ERRADO NA IMAGEM 2!");
             
             
             

            //INSERIR IMAGENS NA BASE DE DADOS DO LATERAL ESQUERDA DO CARRO

            
            $imagemLE = $_FILES['arquivoLE']['tmp_name'];
            $tamanhoLE = $_FILES['arquivoLE']['size'];
            $tipoLE = $_FILES['arquivoLE']['type'];
            $nomeLE= $_FILES['arquivoLE']['name'];
            $selectLE = $_POST['codigo_veiculo_LE'];
            
            if($imagemLE != "none"){
              $fpLE = fopen($imagemLE,"rb");
              $conteudoLE = fread($fpLE,$tamanhoLE);
              $conteudoLE = addslashes($conteudoLE);
              fclose($fpLE);
             }

             $inserirLE = "INSERT INTO imagens_latesquerda (cod_veiculo, nome_imagem_latesquerda, tipo_imagem_latesquerda, tamanho_imagem_latesquerda, imagem_latesquerda)
             SELECT '$selectLE', '$nomeLE', '$tipoLE', '$tamanhoLE', '$conteudoLE'
             FROM cad_veiculos
             WHERE cad_veiculos.cod_veiculo = '$selectLE'";

            mysqli_query($conexao,$inserirLE) or die ("ALGO DEU ERRADO NA IMAGEM 2!");
           

            //INSERIR IMAGENS NA BASE DE DADOS DO LATERAL DIREITA DO CARRO
              
            $imagemLD = $_FILES['arquivoLD']['tmp_name'];
            $tamanhoLD = $_FILES['arquivoLD']['size'];
            $tipoLD = $_FILES['arquivoLD']['type'];
            $nomeLD= $_FILES['arquivoLD']['name'];
            $selectLD = $_POST['codigo_veiculo_LD'];
            
            if($imagemLD != "none"){
              $fpLD = fopen($imagemLD,"rb");
              $conteudoLD = fread($fpLD,$tamanhoLD);
              $conteudoLD = addslashes($conteudoLD);
              fclose($fpLD);
             }

            $inserirLD = "INSERT INTO imagens_latdireita (cod_veiculo, nome_imagem_latdireita, tipo_imagem_latdireita, tamanho_imagem_latdireita, imagem_latdireita)
            SELECT '$selectLD', '$nomeLD', '$tipoLD', '$tamanhoLD', '$conteudoLD'
            FROM cad_veiculos
            WHERE cad_veiculos.cod_veiculo = '$selectLD'";

           mysqli_query($conexao,$inserirLD) or die ("ALGO DEU ERRADO NA IMAGEM 2!");
          

             //INSERIR IMAGENS NA BASE DE DADOS DO CAPÔ CARRO

             $imagemC = $_FILES['arquivoC']['tmp_name'];
             $tamanhoC = $_FILES['arquivoC']['size'];
             $tipoC = $_FILES['arquivoC']['type'];
             $nomeC= $_FILES['arquivoC']['name'];
             $selectC = $_POST['codigo_veiculo_C'];
             
             if($imagemC != "none"){
               $fpC = fopen($imagemC,"rb");
               $conteudoC = fread($fpC,$tamanhoC);
               $conteudoC = addslashes($conteudoC);
               fclose($fpC);

              }
             $inserirC = "INSERT INTO imagens_capo (cod_veiculo, nome_imagem_capo, tipo_imagem_capo, tamanho_imagem_capo, imagem_capo)
             SELECT '$selectLD', '$nomeC', '$tipoC', '$tamanhoC', '$conteudoC'
             FROM cad_veiculos
             WHERE cad_veiculos.cod_veiculo = '$selectC'";
 
            mysqli_query($conexao,$inserirC) or die ("ALGO DEU ERRADO NA IMAGEM 2!");
           

            //INSERIR IMAGENS NA BASE DE DADOS DE PEÇAS DO CARRO

            $imagemP = $_FILES['arquivoP']['tmp_name'];
            $tamanhoP = $_FILES['arquivoP']['size'];
            $tipoP = $_FILES['arquivoP']['type'];
            $nomeP= $_FILES['arquivoP']['name'];
            $selectP = $_POST['codigo_veiculo_P'];
            
            if($imagemP != "none"){
              $fpP = fopen($imagemP,"rb");
              $conteudoP = fread($fpP,$tamanhoP);
              $conteudoP = addslashes($conteudoP);
              fclose($fpP);

             }

            $inserirP = "INSERT INTO imagens_pecas (cod_veiculo, nome_imagem_pecas, tipo_imagem_pecas, tamanho_imagem_pecas, imagem_pecas)
            SELECT '$selectP', '$nomeP', '$tipoP', '$tamanhoP', '$conteudoP'
            FROM cad_veiculos
            WHERE cad_veiculos.cod_veiculo = '$selectP'";

           mysqli_query($conexao,$inserirP) or die ("ALGO DEU ERRADO NA IMAGEM 2!");
         
           echo '<script>';
           echo 'alert("FOTOS CADASTRADAS COM SUCESSO!");';
           echo 'window.location.href = "../PHP/cadfotos.php";'; // Redirecionamento em JavaScript
           echo '</script>';
           exit();




            
?>