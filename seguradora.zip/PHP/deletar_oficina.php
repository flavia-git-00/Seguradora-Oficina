<?php

  include_once('conexao.php');


       
        $oficina = '';
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $oficina = $_POST['oficina'];
        $query = "DELETE FROM cad_oficina WHERE cod_usuario_oficina = '$oficina'";
        
        // Executa a query
        if(mysqli_query($conexao, $query)) {
          echo '<script>';
          echo 'alert("OFICINA DELETADA COM SUCESSO!");';
          echo 'window.location.href = "../PHP/deletar_oficina.php";'; // Redirecionamento em JavaScript
          echo '</script>';
          
        } else {
            echo "Erro ao deletar oficina: " . mysqli_error($conexao);
        }
    
    }

        
  
?>

<DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Seleção de Oficina</title>
        <link rel="stylesheet" href="../CSS/select.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    </head>

    

<body>
   <div class="icons">
        <a href="../HTML/index_seguradora.html" class="back-button"><i class="bi bi-arrow-return-left"></i></a>
    </div>


    <?php
      if (isset($error_message)) {
        echo "<p style='color: red;'>$error_message</p>";
      }
    ?>
<div class="box">
<form enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
<fieldset>
<legend><b> DELETAR OFICINA

</b></legend>

<br> 

    <div class="inputBox"> 
    
    <select name="oficina" class="inputUser" required>
      <?php
        $consulta3 = mysqli_query($conexao, "SELECT cod_usuario_oficina as Cod, cad_nome as Nome FROM cad_oficina");

        while ($resultado3 = mysqli_fetch_array($consulta3)){
          echo "<option value='" .$resultado3['Cod'] ."'>" . $resultado3['Nome'] . "</option>";
        }
      ?>
    </select>
    <label class="labelInput"> OFICINA: </label>
    </div>
    <br><br>
    <br><br>

   <input type="submit" id="submit" value="DELETAR">
    </fieldset>
</form>
</div>
  </body>
    </html>
