
<?php

  include_once('conexao.php');

  $select = '';
  $select2 = '';
  $select3 = '';

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $select = $_POST['select'];
    $select2 = $_POST['select2'];
    $select3 = $_POST['select3'];
   
    if (!($select == $select2 && $select2 == $select3 && $select3 == $select)) {
     
      // Os dados não estão na mesma linha (ID) do banco de dados
      echo "Valores recebidos do formulário: ";
      echo "Marca: " . $select . ", Modelo: " . $select2 . ", Placa: " . $select3 . "<br>"; 
      
      $error_message = "Os dados do veículo selecionado não são congruentes. Por favor, selecione o mesmo veículo para todos os campos.";
    

    
    }else{

      echo '<!DOCTYPE html>';
      echo '<html lang="en">';
      echo '<head>';
      echo '    <meta charset="UTF-8">';
      echo '    <meta name="viewport" content="width=device-width, initial-scale=1.0">';
      echo '    <title>Seleção de Veículo</title>';
      echo '    <link rel="stylesheet" href="../CSS/orcamento2_style.css">';
      echo '    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">';
      echo '    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">';
      echo '</head>';
      echo '<body>';

  echo'<div class="icons">';
    echo'<a href="orcamentoV.php" class="back-button"><i class="bi bi-arrow-return-left"></i></a>';
   echo'</div>';

     echo ' <form enctype="multipart/form-data" action="PaginaPdf.php" method="post">';

     echo'<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>';

     echo '<script src="../JAVA/script.js"> </script>';
     
     $consulta_marca = mysqli_query($conexao, "SELECT marca_veiculo as Marca FROM cad_veiculos WHERE cod_veiculo = '$select'");
     $resultado_marca = mysqli_fetch_array($consulta_marca);
     $marca = $resultado_marca['Marca'];
     echo '<input type="hidden" name="marca" value="' . $marca . '">';

// Consulta SQL para obter o modelo com base no código selecionado
    $consulta_modelo = mysqli_query($conexao, "SELECT modelo_veiculo as Modelo FROM cad_veiculos WHERE cod_veiculo = '$select2'");
    $resultado_modelo = mysqli_fetch_array($consulta_modelo);
    $modelo = $resultado_modelo['Modelo'];
    echo '<input type="hidden" name="modelo" value="' . $modelo . '">';

// Consulta SQL para obter a placa com base no código selecionado
    $consulta_placa = mysqli_query($conexao, "SELECT placa_veiculo as Placa FROM cad_veiculos WHERE cod_veiculo = '$select3'");
    $resultado_placa = mysqli_fetch_array($consulta_placa);
    $placa = $resultado_placa['Placa'];
    echo '<input type="hidden" name="placa" value="' . $placa . '">';

 //////////////////////////////////////////////////////////////////////////////////////////////////////////


   echo '<h1>';
    echo " ORÇAMENTO VEÍCULO: " . $modelo ."<br>";
    echo'</h1>';
  


    echo '<h2 class = "titulo">';
    echo "MARCA: " . $marca ."<br>";
    echo'</h2>';

    echo '<h2 class = "titulo">';
    echo "MODELO: " . $modelo ."<br>";
    echo'</h2>';
 
    echo '<h2 class = "titulo">';
    echo "PLACA: " . $placa ."<br>";
    echo'</h2>';
    echo '<br>';

      // AQUI COMEÇA O CODIGO
echo'<div class="content">';  
   echo '<h2 class="titulo-part">Chassi:</h2>';
    echo '<br>';

    echo'<label>SELECIONE A FOTO: </label>';

    echo '<select name ="codigo_imagem_chassi" id="codigo_imagem_chassi"  onChange ="atualizarImagem()";>';
    $img_chassi = mysqli_query($conexao, "SELECT cod_imagem, nome_imagem FROM imagens WHERE cod_veiculo = '$select3'");
    
    while ($result_img = mysqli_fetch_array($img_chassi)) {
        echo '<option value="' . $result_img['cod_imagem'] . '">' . $result_img['nome_imagem'] . '</option>';
    }
    
    echo '</select>';
    echo '<input type="hidden" name="id_chassi" value="' . $result_img . '">';
    echo'<br>';

    echo '<div id="imagem_chassi">
    </div>';
    
    echo '<input type="hidden" name="codigo_veiculo_CH" value="' . $select3 . '">';
    

    echo'<label>ORÇAMENTO: </label>';
    echo '<input type="number" name="orc_chassi"  placeholder="Digite o orçamento...">';
    echo'<br>';
    echo'<label>DESCRIÇÃO: </label>';
    echo '<textarea name="desc_chassi" rows="4" cols="50" placeholder="Digite a descrição do chassi aqui"></textarea>';

   
    
    //aqui começa o codigo do hodometro
    echo'<h2 class="titulo-part"> Hôdometro: </h2>';
    echo '<br>';
    
    echo'<label>SELECIONE A FOTO: </label>';
    echo '<select name="codigo_hodometro"  id="codigo_imagem_hodometro" onChange= "atualizarImagemH()">';
    $img_hodometro = mysqli_query($conexao, "SELECT cod_imagem_hodometro, nome_imagem_hodometro FROM imagens_hodometro WHERE cod_veiculo = '$select3'");
    
    while ($result_hodometro = mysqli_fetch_array($img_hodometro)) {
        echo '<option value="' . $result_hodometro['cod_imagem_hodometro'] . '">' . $result_hodometro['nome_imagem_hodometro'] . '</option>';
    }

    echo '</select>';
    echo'<br>';
    echo '<div id="imagem_hodometro"></div>';
   
    echo'<label>ORÇAMENTO: </label>';
    echo '<input type="number" name="orc_hodometro" placeholder="Digite o orçamento...">';

    echo '<br>';
    echo '<input type="hidden" name="codigo_veiculo_H" value="' . $select3 . '">';

    echo'<label>DESCRIÇÃO: </label>';
    echo '<textarea name="desc_hodometro" placeholder="Digite a descrição do hodômetro aqui"></textarea>';

  //SELECIONAR IMAGENS FRENTE

    echo'<h2 class="titulo-part"> Frente: </h2>';
    echo '<br>';

    echo'<label>SELECIONE A FOTO: </label>';
    echo '<select name="codigo_frente"  id="cod_img_frente" onChange ="atualizarImagemF()">';
    $img_frente = mysqli_query($conexao, "SELECT cod_imagem_frente, nome_imagem_frente FROM imagens_frente WHERE cod_veiculo = '$select3'");
    
    while ($result_frente = mysqli_fetch_array($img_frente)) {
        echo '<option value="' . $result_frente['cod_imagem_frente'] . '">' . $result_frente['nome_imagem_frente'] . '</option>';
    }

    echo '</select>';
    echo'<br>';

    echo '<div id="imagem_frente"></div>';
    echo'<label>ORÇAMENTO: </label>';

  
    echo '<input type="number" name="orc_frente" placeholder="Digite o orçamento...">';
    echo'<br>';
    echo '<input type="hidden" name="codigo_veiculo_F" value="' . $select3 . '">';

    echo'<label>DESCRIÇÃO: </label>';
    echo '<textarea name="desc_frente" placeholder="Digite a descrição da frente aqui"></textarea>';
    //SELECIONAR IMAGENS TRASEIRA

    echo'<h2 class="titulo-part"> Traseira: </h2>';
    echo '<br>';

  echo'<label>SELECIONE A FOTO: </label>';
    echo '<select name="codigo_traseira"  id="cod_img_traseira" onChange = "atualizarImagemT()" >';
    $img_traseira = mysqli_query($conexao, "SELECT cod_imagem_traseira, nome_imagem_traseira FROM imagens_traseira WHERE cod_veiculo = '$select3'");
    
    while ($result_traseira = mysqli_fetch_array($img_traseira)) {
        echo '<option value="' . $result_traseira['cod_imagem_traseira'] . '">' . $result_traseira['nome_imagem_traseira'] . '</option>';
    }

    echo '</select>';
    echo'<br>';

    echo '<div id="imagem_traseira"></div>';

    echo'<label>ORÇAMENTO: </label>';

    echo '<input type="number" name="orc_traseira" placeholder="Digite o orçamento...">';
    echo'<br>';
    echo '<input type="hidden" name="codigo_veiculo_T" value="' . $select3 . '">';

    echo'<label>DESCRIÇÃO: </label>';
    echo '<textarea name="desc_traseira" placeholder="Digite a descrição da traseira aqui"></textarea>';
  //SELECIONAR IMAGENS LATERAL DIREITA

    echo'<h2 class="titulo-part"> Lateral direita: </h2>';
    echo '<br>';

  echo'<label>SELECIONE A FOTO: </label>';
    echo '<select name="codigo_latdireita"  id="cod_img_latdireita"  onChange="atualizarImagemLD()">';
    $img_latdireita = mysqli_query($conexao, "SELECT cod_imagem_latdireita, nome_imagem_latdireita FROM imagens_latdireita WHERE cod_veiculo = '$select3'");
    
    while ($result_latdireita = mysqli_fetch_array($img_latdireita)) {
        echo '<option value="' . $result_latdireita['cod_imagem_latdireita'] . '">' . $result_latdireita['nome_imagem_latdireita'] . '</option>';
    }

    echo '</select>';
    echo'<br>';
  
    echo '<div id="imagem_latdireita"></div>';
    echo'<label>ORÇAMENTO: </label>';
    echo '<input type="number" name="orc_latdireita" placeholder="Digite o orçamento...">';
    echo'<br>';
    echo '<input type="hidden" name="codigo_veiculo_LD" value="' . $select3 . '">';
    echo'<br>';
    echo'<label>DESCRIÇÃO: </label>';
    echo '<textarea name="desc_latdireita" placeholder="Digite a descrição da lateral direita aqui"></textarea>';
    //SELECIONAR IMAGENS LATERAL ESQUERDA

    echo'<h2 class="titulo-part"> Lateral esquerda: </h2>';
    echo '<br>';

  echo'<label>SELECIONE A FOTO: </label>';

    echo '<select name="codigo_latesquerda"  id="cod_img_latesquerda"  onChange="atualizarImagemLE()">';
    $img_latesquerda = mysqli_query($conexao, "SELECT cod_imagem_latesquerda, nome_imagem_latesquerda FROM imagens_latesquerda WHERE cod_veiculo = '$select3'");
    
    while ($result_latesquerda = mysqli_fetch_array($img_latesquerda)) {
        echo '<option value="' . $result_latesquerda['cod_imagem_latesquerda'] . '">' . $result_latesquerda['nome_imagem_latesquerda'] . '</option>';
    }

    echo '</select>';
    echo'<br>';
    echo '<div id="imagem_latesquerda"></div>';

    echo'<label>ORÇAMENTO: </label>';
    echo '<input type="number" name="orc_latesquerda" placeholder="Digite o orçamento...">';
    echo'<br>';
    echo '<input type="hidden" name="codigo_veiculo_LE" value="' . $select3 . '">';
  
    echo'<label>DESCRIÇÃO: </label>';
    echo '<textarea name="desc_latesquerda" placeholder="Digite a descrição da lateral esquerda aqui"></textarea>';
    // SELECIONAR IMAGENS CAPÔ


    echo'<h2> Câpo: </h2>';
    echo '<br>';

      echo'<label>SELECIONE A FOTO: </label>';
    echo '<select name="codigo_capo"  id="cod_img_capo" onChange="atualizarImagemC()">';
    $img_capo = mysqli_query($conexao, "SELECT cod_imagem_capo, nome_imagem_capo FROM imagens_capo WHERE cod_veiculo = '$select3'");
    
    while ($result_capo = mysqli_fetch_array($img_capo)) {
        echo '<option value="' . $result_capo['cod_imagem_capo'] . '">' . $result_capo['nome_imagem_capo'] . '</option>';
    }

    echo '</select>';
    echo'<br>';

    echo '<div id="imagem_capo"></div>';

    echo'<label>ORÇAMENTO: </label>';
    echo '<input type="number" name="orc_capo" placeholder="Digite o orçamento...">';
    echo'<br>';
    echo '<input type="hidden" name="codigo_veiculo_C" value="' . $select3 . '">';

    echo'<label>DESCRIÇÃO: </label>';
    echo '<textarea name="desc_capo" placeholder="Digite a descrição do capô aqui"></textarea>';
    //IMAGENS PEÇAS DANIFICADAS

    echo'<h2 class="titulo-part"> Peças Danificadas: </h2>';
    echo '<br>';

    echo'<label>SELECIONE A FOTO: </label>';
    echo '<select name="codigo_pecas"  id="cod_img_pecas" onChange = "atualizarImagemP()">';
    $img_pecas = mysqli_query($conexao, "SELECT cod_imagem_pecas, nome_imagem_pecas FROM imagens_pecas WHERE cod_veiculo = '$select3'");
    
    while ($result_pecas = mysqli_fetch_array($img_pecas)) {
        echo '<option value="' . $result_pecas['cod_imagem_pecas'] . '">' . $result_pecas['nome_imagem_pecas'] . '</option>';
    }

    echo '</select>';
    echo'<br>';

    echo '<div id="imagem_pecas"></div>';

    echo'<label>ORÇAMENTO: </label>';
    echo '<input type="number" name="orc_pecas" placeholder="Digite o orçamento...">';
    echo'<br>';
    echo '<input type="hidden" name="codigo_veiculo_P" value="' . $select3 . '">';
    echo'<label>DESCRIÇÃO: </label>';
    echo '<textarea name="desc_pecas" placeholder="Digite a descrição das peças aqui"></textarea> <br>';
  
    echo '<input type="submit" value="GerarPDF" />';

            echo ' </form>';
            echo '<body>';
            echo'</html>';

        exit();
  
        echo'</div>';
    }
  }
?>


<DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Seleção de Veículo</title>
        <link rel="stylesheet" href="../CSS/select.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    </head>

    

<body>
   <div class="icons">
        <a href="../HTML/index_oficina.php" class="back-button"><i class="bi bi-arrow-return-left"></i></a>
    </div>


    <?php
      if (isset($error_message)) {
        echo "<p style='color: red;'>$error_message</p>";
      }
    ?>
<div class="box">
<form enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
<fieldset>
<legend><b> SELECIONE O VEÍCULO

</b></legend>

<br> 

  <div class="inputBox"> 
    <select name="select" class="inputUser" required> 
    <?php
      $consulta = mysqli_query($conexao, "SELECT cod_veiculo as codigo, marca_veiculo as Marca FROM cad_veiculos");

      while ($resultado = mysqli_fetch_array($consulta)) {
        echo "<option value='" . $resultado['codigo'] . "'>" . $resultado['Marca'] ."</option>";
      }
    ?>
    </select>
    <label class="labelInput"> MARCA: </label>
    </div>
    <br><br>

    <div class="inputBox"> 
    
    <select name="select2" class="inputUser" required>
    <?php
      $consulta2 = mysqli_query($conexao, "SELECT cod_veiculo as Cod, modelo_veiculo as Modelo FROM cad_veiculos");

      while ($resultado2 = mysqli_fetch_array($consulta2)){
        echo "<option value='" . $resultado2['Cod'] . "'>" . $resultado2['Modelo'] ."</option>";
      }
    ?>
    </select>
    <label class="labelInput"> Modelo: </label>
    </div>
    <br><br>

    <div class="inputBox"> 
    
    <select name="select3" class="inputUser" required>
      <?php
        $consulta3 = mysqli_query($conexao, "SELECT cod_veiculo as Cod2, placa_veiculo as Placa FROM cad_veiculos");

        while ($resultado3 = mysqli_fetch_array($consulta3)){
          echo "<option value='" .$resultado3['Cod2'] ."'>" . $resultado3['Placa'] . "</option>";
        }
      ?>
    </select>
    <label class="labelInput"> Placa: </label>
    </div>
    <br><br>
    <br><br>

   <input type="submit" id="submit" value="Selecionar">
    </fieldset>
</form>
</div>
  </body>
    </html>
