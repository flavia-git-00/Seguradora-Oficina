<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar</title>
    <style>
        /* Estilo para centralizar o indicador de carregamento */
        .loading-container {
            display: flex;
            justify-content: center;
            align-items: center;
            position: fixed;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: black;
            z-index: 9999;
        }

        .loading-container img {
            border-radius:15px;
            width: 500px;
            height: 400px;
        }
    </style>
</head>
<body>
<!-- Indicador de carregamento -->
<div class="loading-container" id="loading">
    <img src="../IMG/carregar.gif" alt="Carregando...">
</div>

<?php
include_once("conexao.php"); 

$nome = $_POST["seg"];
$usuario = $_POST["userseg"];
$admin = $_POST["adminseg"];
$senha = $_POST["senhaSeg"];
$confirmSenha = $_POST["confirmarsenha"];

// Verificando se as senhas estão iguais

if ($senha !== $confirmSenha) {
    echo '<script type="text/javascript">';
    echo 'alert("As senhas não estão iguais!!!");';
    echo 'location.replace("../HTML/cadastrar_oficina.html");';
    echo '</script>';
} else {
    $insere = mysqli_query($conexao, "INSERT INTO login_seg (cad_nome_seg, cad_adm, cad_usuario, cad_senha) VALUES ('$nome', '$admin', '$usuario', '$senha')") or die(mysqli_error($conexao));
    
    // Escondendo o indicador de carregamento após a conclusão do processo
    echo '<script type="text/javascript">';
    echo 'setTimeout(function() { window.location.href = "../HTML/login_seg.html"; }, 3000);'; // Redireciona após 3 segundos
    echo '</script>';
}
?>
</body>
</html>
