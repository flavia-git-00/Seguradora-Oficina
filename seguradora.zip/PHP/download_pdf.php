<?php

include_once("conexao.php");


if (isset($_POST['id'])) {
    $id = intval($_POST['id']);
    
    // Consulta para recuperar o PDF BLOB
    $sql = "SELECT pdf FROM solicitacao WHERE cod_soli ='$id'";
    $stmt = $conexao->prepare($sql);
    $stmt->execute();
    $stmt->bind_result($pdf_blob);
    $stmt->fetch();
    $stmt->close();
    
    // Envia o PDF para o navegador
    if ($pdf_blob) {
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="documento.pdf"');
        echo $pdf_blob;
    } else {
        echo "PDF não encontrado.";
    }
}


?>