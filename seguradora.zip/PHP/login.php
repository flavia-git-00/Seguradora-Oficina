<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        /* Estilo para centralizar o indicador de carregamento */
        .loading-container {
            background-image: linear-gradient(to right, rgb(0, 0, 0),#737373);
            display: flex;
            justify-content: center;
            align-items: center;
            position: fixed;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: black;
            z-index: 9999;
        }

        .loading-container img {
            width:600px;
            height: 400px;
        }
    </style>
</head>
<body>


<?php
include_once("conexao.php");

$usuario = $_POST["user"];
$senha = $_POST["senha"];

$sql = "SELECT * FROM login_seg WHERE cad_usuario = '$usuario'";
$result = mysqli_query($conexao, $sql);

if ($result && mysqli_num_rows($result) > 0 ) {
    // Usuário encontrado, verificar a senha
    $row = mysqli_fetch_assoc($result);
    $senha_armazenada = $row['cad_senha'];

    if ($senha === $senha_armazenada) {
        // Senha correta, redireciona para a página desejada
       
        echo '<div class="loading-container">';
        echo '<img src="../GIF/loginsucesso.gif" alt="Carregando...">';
        echo '</div>';

        echo '<div id="content" style="display:none;">';


        // Senha correta, redireciona para a página desejada
        echo '<script type="text/javascript">';
        echo 'document.getElementById("content").style.display = "block";'; // Exibe o conteúdo principal
        echo 'setTimeout(function() { window.location.href = "../HTML/index_seguradora.php"; }, 6000);'; // Redireciona após 3 segundos
        echo '</script>';
    } else {
        // Senha incorreta, redireciona de volta para a página de login
      
        echo '<div class="loading-container">';
        echo '<img src="../GIF/senhaincorreta.gif" alt="Carregando...">';
        echo '</div>';

        echo '<div id="content" style="display:none;">';
        
        // Senha correta, redireciona para a página desejada
        echo '<script type="text/javascript">';
        echo 'document.getElementById("content").style.display = "block";'; // Exibe o conteúdo principal
        echo 'setTimeout(function() { window.location.href = "../HTML/login_seg.html"; }, 6000);'; // Redireciona após 3 segundos
        echo '</script>';
    }

} else {
    // Usuário não encontrado, redireciona para a página de cadastro
    echo '<script type="text/javascript">';
    echo 'alert("Usuário não encontrado!!!");';
    echo 'location.replace("../HTML/cadastrar_oficina.html");';
    echo '</script>';
}
?>
</body>
</html>
