<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        /* Estilo para centralizar o indicador de carregamento */
        .loading-container {
          background-image: linear-gradient(to right, rgb(30, 20, 32),#551252);
            display: flex;
            justify-content: center;
            align-items: center;
            position: fixed;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: black;
            z-index: 9999;
        }

        .loading-container img {
            border-radius:15px;
            width:600px;
            height: 400px;
        }
    </style>
</head>
<body>


<?php

  include_once('conexao.php');

  $select = '';
  $select2 = '';
  $select3 = '';

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codigo_marca = $_POST['select'];
    $codigo_modelo = $_POST['select2'];
    $codigo_placa = $_POST['select3'];
   
    if (!($codigo_marca == $codigo_modelo && $codigo_modelo == $codigo_placa && $codigo_placa == $codigo_marca)) {
      echo '<script>';
      echo 'alert("OS DADOS DO VEICULO NÃO SÃO CONGRUENTES, POR FAVOR SELECIONE O MESMO VEICULO PARA TODOS OS CAMPOS!!");';
      echo 'window.location.href = "../PHP/deletar.php";'; // Redirecionamento em JavaScript
      echo '</script>';
      exit();
  } else {
      // Query de exclusão
      $query = "DELETE FROM cad_veiculos WHERE cod_veiculo = '$codigo_placa'";

      if (mysqli_query($conexao, $query)) {
          echo '<div class="loading-container">';
          echo '<img src="../GIF/deletarveiculo.gif" alt="Carregando...">';
          echo '</div>';

          echo '<div id="content" style="display:none;">';

          // Senha correta, redireciona para a página desejada
          echo '<script type="text/javascript">';
          echo 'document.getElementById("content").style.display = "block";'; // Exibe o conteúdo principal
          echo 'setTimeout(function() { window.location.href = "../PHP/deletar.php"; }, 6000);'; // Redireciona após 6 segundos
          echo '</script>';
      } else {
          echo '<script>';
          echo 'alert("[ERRO!] AO TENTAR DELETAR VEÍCULO! (TENTE NOVAMENTE!) ' . mysqli_error($conexao) . '");';
          echo 'window.location.href = "../HTML/carros.html";'; // Redirecionamento em JavaScript
          echo '</script>';
      }
  }
}
   
  
?>

</div>


<script>
    // Exibir o conteúdo principal após o carregamento completo da página
    window.onload = function() {
        document.getElementById('content').style.display = 'block';
    };
</script>
</body>
</html>