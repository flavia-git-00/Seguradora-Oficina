<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Atualizando Oficina...</title>
        <style>
        /* Estilo para centralizar o indicador de carregamento */
        .loading-container {
            background-image: linear-gradient(to right, rgb(30, 20, 32),#551252);
            display: flex;
            justify-content: center;
            align-items: center;
            position: fixed;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: black;
            z-index: 9999;
        }

        .loading-container img {
            border-radius:15px;
            width:600px;
            height: 400px;
        }
    </style>
    </head>
<body>

<div class="loading-container">
    <img src="../GIF/resposta.gif" alt="Carregando...">
</div>

<!-- Seu conteúdo HTML principal (será exibido após o carregamento) -->
<div id="content" style="display:none;">

<?php

include_once("conexao.php");

$cod_veiculo = $_POST['codigo_veiculo'];
$resposta = $_POST['resposta'];
$cod_soli = $_POST['id'];


$insere = "INSERT INTO resposta (cod_veiculo,resposta,cod_soli)
SELECT '$cod_veiculo', '$resposta','$cod_soli'
FROM cad_veiculos
WHERE cad_veiculos.cod_veiculo = '$cod_veiculo'";

$resultado = mysqli_query($conexao,$insere);


if($resultado){

    $update = "UPDATE solicitacao SET status_soli = '$resposta' WHERE cod_soli ='$cod_soli' AND cod_veiculo ='$cod_veiculo'";
    $resultado_update = mysqli_query($conexao, $update);

    echo '<script type="text/javascript">';
    echo 'document.getElementById("content").style.display = "block";'; // Exibe o conteúdo principal
    echo 'setTimeout(function() { window.location.href = "../PHP/responder.php"; }, 5000);'; // Redireciona após 3 segundos
    echo '</script>';

   
}else {
    echo '<script>';
    echo 'alert("[ERRO!] Você não pode responder a mesma solicitação novamente!' . mysqli_error($conexao) . '");';
    echo 'window.location.href = "../PHP/responder.php";'; // Redirecionamento em JavaScript
    echo '</script>';
    exit();
}

?>

</div>

<script>
    // Exibir o conteúdo principal após o carregamento completo da página
    window.onload = function() {
        document.getElementById('content').style.display = 'block';
    };
</script>

    
</body>
</html>