<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atualizar Veículo</title>
    <link rel="stylesheet" href="../CSS/style_atualizar.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body>

<div class = "icons" >
<a href="../HTML/index_seguradora.html" class="back-button"><i class="bi bi-arrow-return-left"></i> </a>
</div>

<?php

  include_once('conexao.php');

  $select = '';
  $select2 = '';
  $select3 = '';

  if ($_SERVER["REQUEST_METHOD"] == "POST") {

      $select = $_POST['select'];
      $select2 = $_POST['select2'];
      $select3 = $_POST['select3'];
   
    if (!($select == $select2 && $select2 == $select3 && $select3 == $select)) {
     
      // Os dados não estão na mesma linha (ID) do banco de dados
      echo "Valores recebidos do formulário: ";
      echo "Marca: " . $select . ", Modelo: " . $select2 . ", Placa: " . $select3 . "<br>"; 
      $error_message = "Os dados do veículo selecionado não são congruentes. Por favor, selecione o mesmo veículo para todos os campos.";
    }

    else {

// CODIGO PARA CONFERIR SE AS INFORMAÇÕES DO CARRO ESTÃO NA MESMA TABELA E ID DO BANCO

     $consulta_marca = mysqli_query($conexao, "SELECT marca_veiculo as Marca FROM cad_veiculos WHERE cod_veiculo = '$select'");
     $resultado_marca = mysqli_fetch_array($consulta_marca);
     $marca = $resultado_marca['Marca'];
     echo '<input type="hidden" name="marca" value="' . $marca . '">';

    // Consulta SQL para obter o modelo com base no código selecionado
    $consulta_modelo = mysqli_query($conexao, "SELECT modelo_veiculo as Modelo FROM cad_veiculos WHERE cod_veiculo = '$select2'");
    $resultado_modelo = mysqli_fetch_array($consulta_modelo);
    $modelo = $resultado_modelo['Modelo'];
    echo '<input type="hidden" name="modelo" value="' . $modelo . '">';

    // Consulta SQL para obter a placa com base no código selecionado
    $consulta_placa = mysqli_query($conexao, "SELECT placa_veiculo as Placa FROM cad_veiculos WHERE cod_veiculo = '$select3'");
    $resultado_placa = mysqli_fetch_array($consulta_placa);
    $placa = $resultado_placa['Placa'];
    echo '<input type="hidden" name="placa" value="' . $placa . '">';

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    
    //////////// ESTE CODIGO FUNCIONA SOMENTE SE AS INFORMAÇÕES DO VEICULO FOREM VERDADEIRAS

    $sql = "SELECT cod_veiculo, marca_veiculo, modelo_veiculo, ano_veiculo,cor_veiculo, placa_veiculo, hodometro_veiculo, chassi_veiculo FROM cad_veiculos
     WHERE cod_veiculo ='$select3'";
    $result = $conexao->query($sql);
// Verifica se há veículos cadastrados
    if ($result->num_rows > 0) {
    // Exibe o formulário para cada veículo
    while ($row = $result->fetch_assoc()) {

       echo '<div class="box">';

        echo '<form action="update_veiculo.php" method="post">';
        echo '<fieldset>';

        echo '<legend><b> Atualizar Carro </b></legend>';
        echo'<br>'; 


        echo '<input type="hidden" name="cod_veiculo" value="' . $row['cod_veiculo'] . '">';
        
        echo '<div class="inputBox">';
        echo '<input class="inputUser" type="text" name="marca" value="' . $row['marca_veiculo'] . '" required>';
        echo '<label class="labelInput for="marca" class="labelInput">Marca do veículo  </label>';
        echo '</div>';
        
        echo '<br><br>';
       
        
        echo '<div class="inputBox">';
        echo '<input class="inputUser" type="text" name="modelo" value="' . $row['modelo_veiculo'] . '" required>';
        echo '<label class="labelInput for="nome" class="labelInput">Modelo do Veiculo  </label>';
        echo '</div>';
        echo '<br><br>';

        echo '<div class="inputBox">';
        echo '<input class="inputUser" type="number" name="ano" value="' . $row['ano_veiculo'] . '" required>';
        echo '<label class="labelInput for="ano" class="labelInput">Ano do veículo</label>';
        echo '</div>';
        echo '<br><br>';

        
        echo '<div class="inputBox">';
       
        echo '<select class="inputUser" name="cor" required>';
        echo '<option value="Vermelho"'.(($row['cor_veiculo'] == 'Vermelho') ? ' selected' : '').'>Vermelho</option>';
        echo '<option value="Azul"'.(($row['cor_veiculo'] == 'Azul') ? ' selected' : '').'>Azul</option>';
        echo '<option value="Verde"'.(($row['cor_veiculo'] == 'Verde') ? ' selected' : '').'>Verde</option>';
        echo '<option value="Preto"'.(($row['cor_veiculo'] == 'Preto') ? ' selected' : '').'>Preto</option>';
        echo '<option value="Branco"'.(($row['cor_veiculo'] == 'Branco') ? ' selected' : '').'>Branco</option>';
        echo '<option value="Prata"'.(($row['cor_veiculo'] == 'Prata') ? ' selected' : '').'>Prata</option>';
        echo '<option value="Cinza"'.(($row['cor_veiculo'] == 'Cinza') ? ' selected' : '').'>Cinza</option>';
        echo '<option value="Amarelo"'.(($row['cor_veiculo'] == 'Amarelo') ? ' selected' : '').'>Amarelo</option>';
        echo '<option value="Laranja"'.(($row['cor_veiculo'] == 'Laranja') ? ' selected' : '').'>Laranja</option>';
        echo '<option value="Roxo"'.(($row['cor_veiculo'] == 'Roxo') ? ' selected' : '').'>Roxo</option>';
        echo '<option value="Marrom"'.(($row['cor_veiculo'] == 'Marrom') ? ' selected' : '').'>Marrom</option>';
        echo '<option value="Dourado"'.(($row['cor_veiculo'] == 'Dourado') ? ' selected' : '').'>Dourado</option>';
        echo '<option value="Rosa"'.(($row['cor_veiculo'] == 'Rosa') ? ' selected' : '').'>Rosa</option>';
        echo '<option value="Bege"'.(($row['cor_veiculo'] == 'Bege') ? ' selected' : '').'>Bege</option>';
        echo '</select>';
        echo '<label for="cor" class="labelInput">Cor do veículo:</label>';
        echo '</div>';
        echo '<br><br>';
        
    
        echo '<div class="inputBox">';
        echo '<input class="inputUser" type="text" name="placa" value="' . $row['placa_veiculo'] . '" required>';
        echo '<label class="labelInput for="ano" class="labelInput"> Placa </label>';
        echo '</div>';
        echo '<br><br>';

        echo '<div class="inputBox">';
        echo '<input class="inputUser" type="number" name="hodometro" value="' . $row['hodometro_veiculo'] . '" required>';
        echo '<label class="labelInput for="hodometro" class="labelInput">Hodômetro</label>';
        echo '</div>';
        echo '<br><br>';
      
        echo '<div class="inputBox">';
        echo '<input class="inputUser" type="text" name="chassi" value="' . $row['chassi_veiculo'] . '" required>';
        echo '<label class="labelInput for="chassi" class="labelInput">Chassi</label>';
        echo '</div>';
        echo '<br><br>';
        echo '<br><br>';

        echo '<input type="submit"  id="submit" value="Atualizar">';

        echo '</fieldset>';
        echo '</form>';
        echo '</div>';
        echo '<br>';

    }
}
  else {
      echo "Nenhum veículo cadastrado.";
  }

        exit();

    }
  }
?>
 </body>
  </html>

<DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Seleção de Veículo</title>
        <link rel="stylesheet" href="../CSS/select.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    </head>

    

<body>
   <div class="icons">
        <a href="../HTML/index_seguradora.html" class="back-button"><i class="bi bi-arrow-return-left"></i></a>
    </div>


    <?php
      if (isset($error_message)) {
        echo "<p style='color: red;'>$error_message</p>";
      }
    ?>
<div class="box">
<form enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
<fieldset>
<legend><b> SELECIONE O VEÍCULO

</b></legend>

<br> 

  <div class="inputBox"> 
    <select name="select" class="inputUser" required> 
    <?php
      $consulta = mysqli_query($conexao, "SELECT cod_veiculo as codigo, marca_veiculo as Marca FROM cad_veiculos");

      while ($resultado = mysqli_fetch_array($consulta)) {
        echo "<option value='" . $resultado['codigo'] . "'>" . $resultado['Marca'] ."</option>";
      }
    ?>
    </select>
    <label class="labelInput"> MARCA: </label>
    </div>
    <br><br>

    <div class="inputBox"> 
    
    <select name="select2" class="inputUser" required>
    <?php
      $consulta2 = mysqli_query($conexao, "SELECT cod_veiculo as Cod, modelo_veiculo as Modelo FROM cad_veiculos");

      while ($resultado2 = mysqli_fetch_array($consulta2)){
        echo "<option value='" . $resultado2['Cod'] . "'>" . $resultado2['Modelo'] ."</option>";
      }
    ?>
    </select>
    <label class="labelInput"> Modelo: </label>
    </div>
    <br><br>

    <div class="inputBox"> 
    
    <select name="select3" class="inputUser" required>
      <?php
        $consulta3 = mysqli_query($conexao, "SELECT cod_veiculo as Cod2, placa_veiculo as Placa FROM cad_veiculos");

        while ($resultado3 = mysqli_fetch_array($consulta3)){
          echo "<option value='" .$resultado3['Cod2'] ."'>" . $resultado3['Placa'] . "</option>";
        }
      ?>
    </select>
    <label class="labelInput"> Placa: </label>
    </div>
    <br><br>
    <br><br>

   <input type="submit" id="submit" value="Selecionar">
    </fieldset>
</form>
</div>
  </body>
    </html>
