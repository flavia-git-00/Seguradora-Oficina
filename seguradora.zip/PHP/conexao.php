<?php

$SERVERNAME = "localhost";
$username = "root";
$password = "";
$dbname = "seguradora";

 $conexao = new mysqli($SERVERNAME, $username, $password, $dbname);

 if ($conexao -> connect_error){

  die("erro no caregamento da pagina" . $conexao->connect_error);
 }


?>