<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro Veiculo</title>
    <style>
        /* Estilo para centralizar o indicador de carregamento */
        .loading-container {
            background-image: linear-gradient(to right, rgb(30, 20, 32),#551252);
            display: flex;
            justify-content: center;
            align-items: center;
            position: fixed;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: black;
            z-index: 9999;
        }

        .loading-container img {
            border-radius:15px;
            width:600px;
            height: 400px;
        }
    </style>
</head>
<body>
<div class="loading-container">
    <img src="../GIF/cadveiculo.gif" alt="Carregando...">
</div>

<!-- Seu conteúdo HTML principal (será exibido após o carregamento) -->
<div id="content" style="display:none;">
    
    <?php

    include_once("conexao.php");

    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $ano = $_POST['ano'];
    $placa = $_POST['placa'];
    $hodometro = $_POST['hodometro'];
    $chassi = $_POST['chassi'];
    $cor = $_POST['cor'];

    $insere = "INSERT INTO cad_veiculos (marca_veiculo, modelo_veiculo, ano_veiculo,cor_veiculo,placa_veiculo, hodometro_veiculo, chassi_veiculo) 
    VALUES ('$marca', '$modelo', '$ano','$cor', '$placa', '$hodometro', '$chassi')";

    $resultado = mysqli_query($conexao,$insere);


    if($resultado){
        echo '<script type="text/javascript">';
        echo 'document.getElementById("content").style.display = "block";'; // Exibe o conteúdo principal
        echo 'setTimeout(function() { window.location.href = "../HTML/carros.html"; }, 5000);'; // Redireciona após 3 segundos
        echo '</script>';
    }else {
        echo '<script>';
        echo 'alert("[ERRO!] AO TENTAR CADASTRAR VEÍCULO! (TENTE NOVAMENTE!) ' . mysqli_error($conexao) . '");';
        echo 'window.location.href = "../HTML/carros.html";'; // Redirecionamento em JavaScript
        echo '</script>';
        exit();
    }

    ?>
</div>

<script>
    // Exibir o conteúdo principal após o carregamento completo da página
    window.onload = function() {
        document.getElementById('content').style.display = 'block';
    };
</script>
    
</body>
</html>