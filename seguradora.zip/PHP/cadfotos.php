
<?php


    include_once('conexao.php');

    $select = '';
    $select2 = '';
    $select3 = '';

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $select = $_POST['select'];
    $select2 = $_POST['select2'];
    $select3 = $_POST['select3'];
   
    if (!($select == $select2 && $select2 == $select3 && $select3 == $select)) {
     
      // Os dados não estão na mesma linha (ID) do banco de dados
      echo "Valores recebidos do formulário: ";
      echo "Marca: " . $select . ", Modelo: " . $select2 . ", Placa: " . $select3 . "<br>"; 
      
      $error_message = "Os dados do veículo selecionado não são congruentes. Por favor, selecione o mesmo veículo para todos os campos.";
     
    }

    else {

echo '<!DOCTYPE html>';
echo '<html lang="en">';
echo '<head>';
echo '    <meta charset="UTF-8">';
echo '    <meta name="viewport" content="width=device-width, initial-scale=1.0">';
echo '    <title> Anexar </title>';
echo '     <script src="../JAVA/mostrarimg.js"></script>';
echo '    <link rel="preconnect" href="https://fonts.googleapis.com">';
echo'<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">';
echo '    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>';
echo '    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700&display=swap" rel="stylesheet">';
echo '<!---Bootstrap Css------>';
echo '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">';
echo '<!---external CSSS------>';
echo '<link rel="stylesheet" href="../CSS/anexo.css">';
echo '</head>';
echo '<body>';

echo'<div class="icons">';
echo'<a href="cadFotos.php" class="back-button"><i class="bi bi-arrow-return-left"></i></a>';
echo'</div>';


     echo ' <form enctype="multipart/form-data" action="upload.php" method="post">';


// aqui começa os anexos!!!


echo '<div class="container py-5">';
echo '    <h1 class="text-center">Anexar Arquivos</h1>';
echo '    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4 py-5">';
echo '        <div class="col">';
echo '            <div class="card" style="width: 18rem;">';
echo '                <img src="../img/fundo.jpg" id="imgtraseira" class="card-img-top" alt="...">';
echo '                <div class="card-body">';
echo '                    <h5>TRASEIRA</h5>';
echo '                    <p class="card-text">Insira uma imagem legível, e bem iluminada para fácil identificação.</p>';
echo '                </div>';
echo '                <div class="d-flex justify-content-around mb-5">';
echo '                    <div class="cam">';
echo '                        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-camera-fill" viewBox="0 0 16 16">';
echo '                            <path d="M10.5 8.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0"/>';
echo '                            <path d="M2 4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-1.172a2 2 0 0 1-1.414-.586l-.828-.828A2 2 0 0 0 9.172 2H6.828a2 2 0 0 0-1.414.586l-.828.828A2 2 0 0 1 3.172 4zm.5 2a.5.5 0 1 1 0-1 .5.5 0 0 1 0 1m9 2.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0"/>';
echo '                        </svg>';
echo '                       <a href="../HTML/imagens_cadastrar.html">';
echo '                        <label for="fileInputTraseira" class="custom-file-upload">';
echo '                            <input type="file"  name="arquivoT" accept="image/*" id="fileInputTraseira" onchange="exibirImagem(event)" style="display: none;">';
echo '<input type="hidden" name="codigo_veiculo_T" value="' . $select3 . '">';
echo '                            <span>Selecionar arquivo</span>';
echo '                        </label>';
echo '                        </a>';
echo '                    </div>';
echo '                </div>';
echo '            </div>';
echo '        </div>';

// aqui começa o codigo da frente!!!/////////////////////////////////

echo '<div class="col">';
echo '    <div class="card" style="width: 18rem;">';
echo '        <img src="../IMG/frente.jpg" id="imgfrente" class="card-img-top" alt="...">';
echo '        <div class="card-body">';
echo '            <h5>FRENTE</h5>';
echo '            <p class="card-text">Insira uma imagem legível, e bem iluminada para fácil identificação.</p>';
echo '        </div>';
echo '        <div class="d-flex justify-content-around mb-5">';
echo '            <div>';
echo '                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-camera-fill" viewBox="0 0 16 16">';
echo '                    <path d="M10.5 8.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0"/>';
echo '                    <path d="M2 4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-1.172a2 2 0 0 1-1.414-.586l-.828-.828A2 2 0 0 0 9.172 2H6.828a2 2 0 0 0-1.414.586l-.828.828A2 2 0 0 1 3.172 4zm.5 2a.5.5 0 1 1 0-1 .5.5 0 0 1 0 1m9 2.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0"/>';
echo '                </svg>';
echo '                <a href="../HTML/imagens_cadastrar.html">';
echo '                    <label for="fileInputFrente" class="custom-file-upload">';
echo '                        <input type="file" accept="image/*" name="arquivoF" id="fileInputFrente" onchange="exibirImagemF(event)" style="display: none;">';
echo                           '<input type="hidden" name="codigo_veiculo_F" value="' . $select3 . '">';
echo '                        <span>Selecionar arquivo</span>';
echo '                    </label>';
echo '                </a>';
echo '            </div>';
echo '        </div>';
echo '    </div>';
echo '</div>';


/// aqui começa o codigo lateral esquerda!!/////////////////////////////////

echo '<div class="col">';
echo '<div class="card" style="width: 18rem;">';
   echo'<img src="../IMG/esquerda.jpg" id="imgesquerda" class="card-img-top" alt="...">';
    echo'<div class="card-body">';
    echo ' <h5>LATERAL ESQUERDA</h5>';
    echo ' <p class="card-text">Insira uma imagem legível, e bem iluminada para fácil identificação.</p>';
      echo '</div>';
       echo '<div class="d-flex justify-content-around mb-5">';
       echo '<div>';
      echo '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-camera-fill" viewBox="0 0 16 16">';
              echo'<path d="M10.5 8.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0"/>';
                 echo '<path d="M2 4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-1.172a2 2 0 0 1-1.414-.586l-.828-.828A2 2 0 0 0 9.172 2H6.828a2 2 0 0 0-1.414.586l-.828.828A2 2 0 0 1 3.172 4zm.5 2a.5.5 0 1 1 0-1 .5.5 0 0 1 0 1m9 2.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0"/>';
               echo'</svg>';
                echo '<a href="https://imgur.com/n7P0DP9"></a>';
                echo '<label for="fileInputLE" class="custom-file-upload">';
                  echo ' <input type="file" name="arquivoLE" accept="image/*" id="fileInputLE" onchange="exibirImagemLE(event)" style="display: none;">';
                  echo '<input type="hidden" name="codigo_veiculo_LE" value="' . $select3 . '">';
                  echo' <span>Selecionar arquivo</span>';
              echo'</label>';
          echo '</a>';
       echo' </div>';
   echo' </div>';
echo '</div>';
echo'</div>';

// aqui começa o codigo da lateral direita!!! ////

echo'<div class="col">';
echo'<div class="card" style="width: 18rem;">';
  echo'  <img src="../IMG/direita.jpg" id="imgdireita" class="card-img-top" alt="...">';
   echo' <div class="card-body">';
          echo'  <h5>LATERAL DIREITA</h5>';
         echo'<p class="card-text">Insira uma imagem legível, e bem iluminada para fácil identificação.</p>';
          echo'</div>';
         echo'<div class="d-flex justify-content-around mb-5">';
           echo'<div>';
              echo'<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-camera-fill" viewBox="0 0 16 16">';
                 echo'<path d="M10.5 8.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0"/>';
                  echo'<path d="M2 4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-1.172a2 2 0 0 1-1.414-.586l-.828-.828A2 2 0 0 0 9.172 2H6.828a2 2 0 0 0-1.414.586l-.828.828A2 2 0 0 1 3.172 4zm.5 2a.5.5 0 1 1 0-1 .5.5 0 0 1 0 1m9 2.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0"/>';
               echo' </svg>';
                echo'<a href="https://imgur.com/n7P0DP9"></a>';
                echo'<label for="fileInputLD" class="custom-file-upload">';
                  echo' <input type="file" name="arquivoLD" accept="image/*" id="fileInputLD" onchange="exibirImagemLD(event)" style="display: none;">';
                  echo '<input type="hidden" name="codigo_veiculo_LD" value="' . $select3 . '">';
                  echo' <span>Selecionar arquivo</span>';
                echo'</label>';
           echo'</a>';
        echo'</div>';
   echo' </div>';
echo '</div>';
echo'</div>';

/// aqui começa o codigo do chassi!!!//////////////////

echo'<div class="col">';
            echo'<div class="card" style="width: 18rem;">';
                echo'<img src="../IMG/chassi.jpg" id="imgchassi" class="card-img-top" alt="...">';
                echo'<div class="card-body">';
                 echo '<h5>CHASSI</h5>';
                  echo'<p class="card-text">Insira uma imagem legível, e bem iluminada para fácil identificação.</p>';
               echo'</div>';
               echo' <div class="d-flex justify-content-around mb-5">';
                    echo'<div>';
                  echo'<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-camera-fill" viewBox="0 0 16 16">';
                    echo'<path d="M10.5 8.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0"/>';
                        echo'<path d="M2 4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-1.172a2 2 0 0 1-1.414-.586l-.828-.828A2 2 0 0 0 9.172 2H6.828a2 2 0 0 0-1.414.586l-.828.828A2 2 0 0 1 3.172 4zm.5 2a.5.5 0 1 1 0-1 .5.5 0 0 1 0 1m9 2.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0"/>';
                       echo'</svg>';
                        echo'<a href="../HTML/imagens_cadastrar.html">';
                           echo' <label for="fileInputCH" class="custom-file-upload">';
                           echo' <input name="arquivo" type="file"  accept="image/*" id="fileInputCH" onchange="exibirImagemCH(event)" style="display: none;">';
                           echo '<input type="hidden" name="codigo_veiculo" value="' . $select3 . '">';
                           echo' <span>Selecionar arquivo</span>';
                       echo' </label>';
                      echo'</a>';
                   echo'</div>';
                echo'</div>';
            
        echo'</div>';
                 
        echo'</div>';

        //aqui começa o codigo do hodometro!!!!!/////////////////////////////////////////////////////

        echo'<div class="col">';
        echo'<div class="card" style="width: 18rem;">';
           echo'<img src="../IMG/hodometro.webp" id="imghodometro" class="card-img-top" alt="...">';
            echo'<div class="card-body">';
               echo' <h5>HODOMETRO</h5>';
                echo'<p class="card-text">Insira uma imagem legível, e bem iluminada para fácil identificação.</p>';
           echo'</div>';
            echo'<div class="d-flex justify-content-around mb-5">';
                echo'<div>';
                  echo'<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-camera-fill" viewBox="0 0 16 16">';
                       echo'<path d="M10.5 8.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0"/>';
                        echo '<path d="M2 4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-1.172a2 2 0 0 1-1.414-.586l-.828-.828A2 2 0 0 0 9.172 2H6.828a2 2 0 0 0-1.414.586l-.828.828A2 2 0 0 1 3.172 4zm.5 2a.5.5 0 1 1 0-1 .5.5 0 0 1 0 1m9 2.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0"/>';
                   echo'</svg>';
                    echo'<a href="../HTML/imagens_cadastrar.html">';
                      echo'  <label for="fileInputH" class="custom-file-upload">';
                        echo'<input type="file" name="arquivoH" accept="image/*" id="fileInputH" onchange="exibirImagemH(event)" style="display: none;">';
                        echo '<input type="hidden" name="codigo_veiculo_H" value="' . $select3 . '">';
                        echo'<span>Selecionar arquivo</span>';
                    echo'</label>';
                    echo'</a>';
                echo'</div>';
            echo'</div>';
        
            echo'</div>';
          echo'</div>';

          //aqui começa o codigo do CAPÔ!!!!///////////////////////////////////////////

          echo'<div class="col">';
        echo'<div class="card" style="width: 18rem;">';
           echo' <img src="../IMG/capo.jpg" id="imgcapo" class="card-img-top" alt="...">';
            echo'<div class="card-body">';
                echo'<h5>CAPO ABERTO</h5>';
                echo'<p class="card-text">Insira uma imagem legível, e bem iluminada para fácil identificação.</p>';
            echo'</div>';
           echo' <div class="d-flex justify-content-around mb-5">';
                echo'<div>';
                    echo'<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-camera-fill" viewBox="0 0 16 16">';
                        echo'<path d="M10.5 8.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0"/>';
                        echo'<path d="M2 4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-1.172a2 2 0 0 1-1.414-.586l-.828-.828A2 2 0 0 0 9.172 2H6.828a2 2 0 0 0-1.414.586l-.828.828A2 2 0 0 1 3.172 4zm.5 2a.5.5 0 1 1 0-1 .5.5 0 0 1 0 1m9 2.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0"/>';
                   echo'</svg>';
                    echo'<a href="../HTML/imagens_cadastrar.html">';
                        echo'<label for="fileInputC" class="custom-file-upload">';
                        echo'<input type="file" name="arquivoC"  accept="image/*" id="fileInputC" onchange="exibirImagemC(event)" style="display: none;">';
                        echo '<input type="hidden" name="codigo_veiculo_C" value="' . $select3 . '">';
                        echo'<span>Selecionar arquivo</span>';
                        echo'</label>';
                    echo'</a>';
                echo'</div>';
            echo'</div>';  
    echo'</div>'; 
echo'</div>';

//aqui começa o codigo das peças danificadas!!!////////////////////////////////////////////////////

echo'<div class="col">';
    echo'<div class="card" style="width: 18rem;">';
        echo'<img src="../IMG/danos2.jpg" id="imgpecas" class="card-img-top" alt="...">';
        echo'<div class="card-body">';
           echo'<h5>  PEÇAS DANIFICADAS</h5>';
           echo'<p class="card-text">Insira uma imagem legível, e bem iluminada para fácil identificação.</p>';
        echo'</div>';
        echo'<div class="d-flex justify-content-around mb-5">';
            echo'<div>';
               echo'<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-camera-fill" viewBox="0 0 16 16">';
                    echo'<path d="M10.5 8.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0"/>';
                    echo'<path d="M2 4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-1.172a2 2 0 0 1-1.414-.586l-.828-.828A2 2 0 0 0 9.172 2H6.828a2 2 0 0 0-1.414.586l-.828.828A2 2 0 0 1 3.172 4zm.5 2a.5.5 0 1 1 0-1 .5.5 0 0 1 0 1m9 2.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0"/>';
                echo'</svg>';
              
                echo'<a href="../HTML/imagens_cadastrar.html">';
                  echo'<label for="fileInputP" class="custom-file-upload">';
                    echo'<input type="file" name="arquivoP" accept="image/*" id="fileInputP" onchange="exibirImagemP(event)" style="display: none;">';
                    echo '<input type="hidden" name="codigo_veiculo_P" value="' . $select3 . '">';
                    echo'<span>Selecionar arquivo</span>';
               echo'</label>';
                echo'</a>';
           echo'</div>';
        echo'</div>';
    
       echo'</div>';

      echo' <div id="submit-container">';
   echo'<input type="submit" class="submit2" id="submit2" value="Salvar" style="background-image: linear-gradient(to right, rgb(255, 255, 255),#ccb8cb); border: none; color: rgb(0, 0, 0); padding: 15px 20px; text-align: center; text-decoration: none; display: inline-block; font-size: 16px; margin: 4px 2px; cursor: pointer; border-radius: 4px; width: 72%; border-radius: 50px; margin-top: 100px;">
   ';
    echo'</div>';
          echo ' </form>';

      echo' </body>';
        echo '</html>';

          exit();
  

    }
  }
?>



<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Seleção de Veículo</title>
        <link rel="stylesheet" href="../CSS/select.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    </head>

 <body>

 <div class="icons">
        <a href="../HTML/index_oficina.php" class="back-button"><i class="bi bi-arrow-return-left"></i></a>
  </div>



    <?php
      if (isset($error_message)) {
        echo "<p style='color: red;'>$error_message</p>";
      }
    ?>

<div class="box">
  <form enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
  <fieldset>

  <legend><b> SELECIONE O VEÍCULO

    </b></legend>

    <br>   

    <div class="inputBox"> 
   <select class="inputUser" name="select"> 
      <?php
        $consulta = mysqli_query($conexao, "SELECT cod_veiculo as codigo, marca_veiculo as Marca FROM cad_veiculos");

        while ($resultado = mysqli_fetch_array($consulta)) {
          echo "<option value='" . $resultado['codigo'] . "'>" . $resultado['Marca'] ."</option>";
        }
      ?>
   </select>
   <label class="labelInput"> MARCA: </label>
      </div> 
      <br><br>

   
   <div class="inputBox"> 
   <select class="inputUser" name="select2">
    <?php
      $consulta2 = mysqli_query($conexao, "SELECT cod_veiculo as Cod, modelo_veiculo as Modelo FROM cad_veiculos");

      while ($resultado2 = mysqli_fetch_array($consulta2)){
        echo "<option value='" . $resultado2['Cod'] . "'>" . $resultado2['Modelo'] ."</option>";
      }
    ?>
   </select>
   <label class="labelInput"> Modelo: </label>
    </div> 
    <br><br>

   
   <div class="inputBox"> 
   <select class="inputUser" name="select3">
      <?php
        $consulta3 = mysqli_query($conexao, "SELECT cod_veiculo as Cod2, placa_veiculo as Placa FROM cad_veiculos");

        while ($resultado3 = mysqli_fetch_array($consulta3)){
          echo "<option value='" .$resultado3['Cod2'] ."'>" . $resultado3['Placa'] . "</option>";
        }
   ?>
   </select>
   <label class="labelInput"> Placa: </label>
      </div> 
      <br><br>


   <input type="submit" id="submit" value="Selecionar">

   </fieldset>
     </form> 
       </div>
        </body>
          </html>
