<?php

  include_once('conexao.php');

  $select = '';
  $select2 = '';
  $select3 = '';

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codigo_marca = $_POST['select'];
    $codigo_modelo = $_POST['select2'];
    $codigo_placa = $_POST['select3'];
   
    if (!($codigo_marca == $codigo_modelo && $codigo_modelo == $codigo_placa && $codigo_placa == $codigo_marca)) {
     
      // Os dados não estão na mesma linha (ID) do banco de dados
      echo "Valores recebidos do formulário: ";
      echo "Marca: " . $codigo_marca . ", Modelo: " . $codigo_modelo . ", Placa: " . $codigo_placa . "<br>"; 
      
      $error_message = "Os dados do veículo selecionado não são congruentes. Por favor, selecione o mesmo veículo para todos os campos.";

    }

    else {

        // Obtém o valor selecionado do select    
        // Query de exclusão
        $query = "DELETE FROM cad_veiculos WHERE cod_veiculo = '$codigo_placa'";
        
        // Executa a query
        if(mysqli_query($conexao, $query)) {
          echo '<script>';
          echo 'alert("VEÍCULO DELETADO COM SUCESSO!");';
          echo 'window.location.href = "../PHP/selectcarro.php";'; // Redirecionamento em JavaScript
          echo '</script>';
          exit();
        } else {
            echo "Erro ao deletar imagem: " . mysqli_error($conexao);
        }
    


    }
  }
?>

<DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Seleção de Veículo</title>
        <link rel="stylesheet" href="../CSS/select.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    </head>

    

<body>
   <div class="icons">
        <a href="../HTML/index_seguradora.html" class="back-button"><i class="bi bi-arrow-return-left"></i></a>
    </div>


    <?php
      if (isset($error_message)) {
        echo "<p style='color: red;'>$error_message</p>";
      }
    ?>
<div class="box">
<form enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
<fieldset>
<legend><b> DELETAR VEICULO

</b></legend>

<br> 

  <div class="inputBox"> 
    <select name="select" class="inputUser" required> 
    <?php
      $consulta = mysqli_query($conexao, "SELECT cod_veiculo as codigo, marca_veiculo as Marca FROM cad_veiculos");

      while ($resultado = mysqli_fetch_array($consulta)) {
        echo "<option value='" . $resultado['codigo'] . "'>" . $resultado['Marca'] ."</option>";
      }
    ?>
    </select>
    <label class="labelInput"> MARCA: </label>
    </div>
    <br><br>

    <div class="inputBox"> 
    
    <select name="select2" class="inputUser" required>
    <?php
      $consulta2 = mysqli_query($conexao, "SELECT cod_veiculo as Cod, modelo_veiculo as Modelo FROM cad_veiculos");

      while ($resultado2 = mysqli_fetch_array($consulta2)){
        echo "<option value='" . $resultado2['Cod'] . "'>" . $resultado2['Modelo'] ."</option>";
      }
    ?>
    </select>
    <label class="labelInput"> Modelo: </label>
    </div>
    <br><br>

    <div class="inputBox"> 
    
    <select name="select3" class="inputUser" required>
      <?php
        $consulta3 = mysqli_query($conexao, "SELECT cod_veiculo as Cod2, placa_veiculo as Placa FROM cad_veiculos");

        while ($resultado3 = mysqli_fetch_array($consulta3)){
          echo "<option value='" .$resultado3['Cod2'] ."'>" . $resultado3['Placa'] . "</option>";
        }
      ?>
    </select>
    <label class="labelInput"> Placa: </label>
    </div>
    <br><br>
    <br><br>

   <input type="submit" id="submit" value="DELETAR">
    </fieldset>
</form>
</div>
  </body>
    </html>
