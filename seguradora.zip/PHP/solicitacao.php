<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solicitar Seguro</title>
    <link rel="stylesheet" href="../CSS/style_atualizar.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">


  </head>
<body>

<div class = "icons" >
<a href="solicitacao.php" class="back-button"><i class="bi bi-arrow-return-left"></i> </a>
</div>

<?php

  include_once('conexao.php');

  $select = '';
  $select2 = '';
  $select3 = '';

  if ($_SERVER["REQUEST_METHOD"] == "POST") {

      $select = $_POST['select'];
      $select2 = $_POST['select2'];
      $select3 = $_POST['select3'];
   
    if (!($select == $select2 && $select2 == $select3 && $select3 == $select)) {
     
      // Os dados não estão na mesma linha (ID) do banco de dados
      echo "Valores recebidos do formulário: ";
      echo "Marca: " . $select . ", Modelo: " . $select2 . ", Placa: " . $select3 . "<br>"; 
      $error_message = "Os dados do veículo selecionado não são congruentes. Por favor, selecione o mesmo veículo para todos os campos.";
    }

    else {

       
        echo '<!DOCTYPE html>';
        echo '<html lang="pt-BR">';
        echo '<head>';
        echo '    <meta charset="UTF-8">';
        echo '    <meta name="viewport" content="width=device-width, initial-scale=1.0">';
        echo '<link rel="stylesheet" href="../CSS/style_atualizar.css">';
        echo '    <title>Solicitação de Orçamento</title>';
        echo '</head>';
        echo '<body>';
        echo '<div class="box">';
        echo '    <form action="envio_solicitacao.php" method="post" enctype="multipart/form-data">';
       
        echo '<fieldset>';

        echo '<legend><b> Solicitar Seguro </b></legend>';
        echo'<br>'; 

        echo '<div class="inputBox">';
        echo '        <input type="number" class="inputUser" id="valor" name="valor" required><br><br>';
        echo '        <label  class="labelInput" for="valor">Valor Total:</label>';
        echo '<div>';
        echo '<br><br>';

        echo '<div class="inputBox">';
        echo '        <input type="text" class="inputUser" id="descricao" name="descricao" required><br><br>';
        echo '        <label  class="labelInput" for="descricao">Descrição:</label>';
        echo '<div>';
        echo '<br><br>';

        echo '<div class="inputBox">';
        echo '        <input type="file" class="inputUser" id="arquivo" name="pdf" accept=".pdf"><br><br>';
        echo '        <label  class="labelInput" for="arquivo">Arquivo:</label>';
        echo '<div>';
        echo '<br><br>';

        echo '<input type="hidden" name="codigo_veiculo" value="' . $select3 . '">';
        
        echo '        <input type="submit" id="submit" value="Enviar Solicitacão">';

        echo '</fieldset>';
        echo '</form>';
        echo '</div>';
        echo '<br>';

      exit();
        




    }
}
  else {
      echo "Nenhum veículo cadastrado.";
  }

    


  
?>
 </body>
  </html>


<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Seleção de Veículo</title>
        <link rel="stylesheet" href="../CSS/select.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    </head>

 <body>

 <div class="icons">
        <a href="../HTML/index_oficina.php" class="back-button"><i class="bi bi-arrow-return-left"></i></a>
  </div>



    <?php
      if (isset($error_message)) {
        echo "<p style='color: red;'>$error_message</p>";
      }
    ?>

<div class="box">
  <form enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
  <fieldset>

  <legend><b> SELECIONE O VEÍCULO

    </b></legend>

    <br>   

    <div class="inputBox"> 
   <select class="inputUser" name="select"> 
      <?php
        $consulta = mysqli_query($conexao, "SELECT cod_veiculo as codigo, marca_veiculo as Marca FROM cad_veiculos");

        while ($resultado = mysqli_fetch_array($consulta)) {
          echo "<option value='" . $resultado['codigo'] . "'>" . $resultado['Marca'] ."</option>";
        }
      ?>
   </select>
   <label class="labelInput"> MARCA: </label>
      </div> 
      <br><br>

   
   <div class="inputBox"> 
   <select class="inputUser" name="select2">
    <?php
      $consulta2 = mysqli_query($conexao, "SELECT cod_veiculo as Cod, modelo_veiculo as Modelo FROM cad_veiculos");

      while ($resultado2 = mysqli_fetch_array($consulta2)){
        echo "<option value='" . $resultado2['Cod'] . "'>" . $resultado2['Modelo'] ."</option>";
      }
    ?>
   </select>
   <label class="labelInput"> Modelo: </label>
    </div> 
    <br><br>

   
   <div class="inputBox"> 
   <select class="inputUser" name="select3">
      <?php
        $consulta3 = mysqli_query($conexao, "SELECT cod_veiculo as Cod2, placa_veiculo as Placa FROM cad_veiculos");

        while ($resultado3 = mysqli_fetch_array($consulta3)){
          echo "<option value='" .$resultado3['Cod2'] ."'>" . $resultado3['Placa'] . "</option>";
        }
   ?>
   </select>
   <label class="labelInput"> Placa: </label>
      </div> 
      <br><br>


   <input type="submit" id="submit" value="Selecionar">

   </fieldset>
     </form> 
       </div>
        </body>
          </html>
