<?php
// Conectar ao banco de dados
include_once('conexao.php');

echo '<!DOCTYPE html>';
echo '<html lang="en">';
echo '    <head>';
echo '        <meta charset="UTF-8">';
echo '        <meta name="viewport" content="width=device-width, initial-scale=1.0">';
echo '        <title>Seleção de Veículo</title>';
echo '        <link rel="stylesheet" href="../CSS/select.css">';
echo '        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">';
echo '        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">';
echo '    </head>';
echo '';
echo '    <body>';
echo '        <div class="icons">';
echo '            <a href="../PHP/selectimg.php" class="back-button"><i class="bi bi-arrow-return-left"></i></a>';
echo '        </div>';
echo '    </body>';
echo '</html>';

echo '<div class="box">';

echo '<form method="post" action="processar_exclusao.php">';
echo '<fieldset>';
echo '    <legend><b>SELECIONE A IMAGEM</b></legend>';
echo '    <br>';

echo '<div class="inputBox">';

// Verificar se o código da imagem foi recebido
if(isset($_POST['opcao'])) {

  // Obter o código da imagem
  $opcao = $_POST['opcao'];
  $codigo_veiculo = $_POST['codigo_veiculo'];

  if($opcao == 'chassi'){
   
    echo '<select class="inputUser" name="codigo_imagem_chassi" id="codigo_imagem_chassi" onChange="atualizarImagem()">';
    $img_chassi = mysqli_query($conexao, "SELECT cod_veiculo, cod_imagem, nome_imagem FROM imagens WHERE cod_veiculo = '$codigo_veiculo'");
    
    while ($result_img = mysqli_fetch_array($img_chassi)) {
        echo '<option value="' . $result_img['cod_imagem'] . '">' . $result_img['nome_imagem'] . '</option>';
    }
    
    echo '</select>';
    echo '    <label class="labelInput">Imagens Chassi</label>';
 
    echo '</div>';

    echo '<br><br>';

  } else if($opcao=='hodometro'){

    echo '<div class="inputBox">';

    echo '<select class="inputUser" name="codigo_hodometro"  id="codigo_imagem_hodometro" onChange="atualizarImagemH()">';
    $img_hodometro = mysqli_query($conexao, "SELECT cod_imagem_hodometro, nome_imagem_hodometro FROM imagens_hodometro WHERE cod_veiculo = '$codigo_veiculo'");
    
    while ($result_hodometro = mysqli_fetch_array($img_hodometro)) {
        echo '<option value="' . $result_hodometro['cod_imagem_hodometro'] . '">' . $result_hodometro['nome_imagem_hodometro'] . '</option>';
    }
    echo '</select>';
    echo '    <label class="labelInput">Imagens Hodômetro</label>';

    echo '</div>';

    echo '<br><br>';
  
  } else if($opcao == 'frente'){
    echo '<div class="inputBox">';
    echo '<select class="inputUser" name="codigo_frente"  id="cod_img_frente" onChange="atualizarImagemF()">';
    $img_frente = mysqli_query($conexao, "SELECT cod_imagem_frente, nome_imagem_frente FROM imagens_frente WHERE cod_veiculo = '$codigo_veiculo'");
    
    while ($result_frente = mysqli_fetch_array($img_frente)) {
        echo '<option value="' . $result_frente['cod_imagem_frente'] . '">' . $result_frente['nome_imagem_frente'] . '</option>';
    }

    echo '</select>';
    echo '    <label class="labelInput">Imagens Frente</label>';
    echo '</div>';
    echo '<br><br>';

  } else if($opcao == 'traseira'){

    echo '<div class="inputBox">';
    echo '<select class="inputUser" name="codigo_traseira"  id="cod_img_traseira" onChange="atualizarImagemT()">';
    $img_traseira = mysqli_query($conexao, "SELECT cod_imagem_traseira, nome_imagem_traseira FROM imagens_traseira WHERE cod_veiculo = '$codigo_veiculo'");
    
    while ($result_traseira = mysqli_fetch_array($img_traseira)) {
        echo '<option value="' . $result_traseira['cod_imagem_traseira'] . '">' . $result_traseira['nome_imagem_traseira'] . '</option>';
    }
    echo '</select>';
    echo '    <label class="labelInput">Imagens Traseira</label>';
    echo '</div>';
    echo '<br><br>';

  } else if($opcao == 'latdireita'){

    echo '<div class="inputBox">';
    echo '<select class="inputUser" name="codigo_latdireita"  id="cod_img_latdireita"  onChange="atualizarImagemLD()">';
    $img_latdireita = mysqli_query($conexao, "SELECT cod_imagem_latdireita, nome_imagem_latdireita FROM imagens_latdireita WHERE cod_veiculo = '$codigo_veiculo'");
    
    while ($result_latdireita = mysqli_fetch_array($img_latdireita)) {
        echo '<option value="' . $result_latdireita['cod_imagem_latdireita'] . '">' . $result_latdireita['nome_imagem_latdireita'] . '</option>';
    }

    echo '</select>';
    echo '    <label class="labelInput">Imagens Lateral Direita</label>';
    echo '</div>';
    echo '<br><br>';

  } else if($opcao == 'latesquerda'){

    echo '<div class="inputBox">';
    echo '<select class="inputUser" name="codigo_latesquerda"  id="cod_img_latesquerda"  onChange="atualizarImagemLE()">';
    $img_latesquerda = mysqli_query($conexao, "SELECT cod_imagem_latesquerda, nome_imagem_latesquerda FROM imagens_latesquerda WHERE cod_veiculo = '$codigo_veiculo'");
    
    while ($result_latesquerda = mysqli_fetch_array($img_latesquerda)) {
        echo '<option value="' . $result_latesquerda['cod_imagem_latesquerda'] . '">' . $result_latesquerda['nome_imagem_latesquerda'] . '</option>';
    }

    echo '</select>';
    echo '    <label class="labelInput">Imagens Lateral Esquerda</label>';
    echo '</div>';
    echo '<br><br>';

  } else if($opcao == 'capo'){
    echo '<div class="inputBox">';
    echo '<select class="inputUser" name="codigo_capo"  id="cod_img_capo" onChange="atualizarImagemC()">';
    $img_capo = mysqli_query($conexao, "SELECT cod_imagem_capo, nome_imagem_capo FROM imagens_capo WHERE cod_veiculo = '$codigo_veiculo'");
    
    while ($result_capo = mysqli_fetch_array($img_capo)) {
        echo '<option value="' . $result_capo['cod_imagem_capo'] . '">' . $result_capo['nome_imagem_capo'] . '</option>';
    }

    echo '</select>';
    echo '    <label class="labelInput">Imagens Capô</label>';
    echo '</div>';
    echo '<br><br>';

  } else if($opcao == 'peca'){
    
    echo '<div class="inputBox">';
    echo '<select class="inputUser" name="codigo_pecas"  id="cod_img_pecas" onChange="atualizarImagemP()">';
    $img_pecas = mysqli_query($conexao, "SELECT cod_imagem_pecas, nome_imagem_pecas FROM imagens_pecas WHERE cod_veiculo = '$codigo_veiculo'");
    
    while ($result_pecas = mysqli_fetch_array($img_pecas)) {
        echo '<option value="' . $result_pecas['cod_imagem_pecas'] . '">' . $result_pecas['nome_imagem_pecas'] . '</option>';
    }

    echo '</select>';
    echo '    <label class="labelInput">Imagens Peças</label>';
    echo '</div>';
    echo '<br><br>';

  }

  echo '<input type="hidden" name="opcao" value="' . $opcao . '">';
  echo '<input type="hidden" name="codigo_veiculo" value="' . $codigo_veiculo . '">';
  echo '<input type="submit" id="submit" name="deletar_imagem" value="Deletar" />';

  echo '</fieldset>';
  echo '</form>';
  echo '</div>';
  echo '</body>';
  echo '</html>';
}

?>
