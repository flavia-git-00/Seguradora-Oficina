<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atualizar Oficina</title>
    <link rel="stylesheet" href="../CSS/style_atualizar.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body>

<div class = "icons" >
<a href="../HTML/index_seguradora.html" class="back-button"><i class="bi bi-arrow-return-left"></i> </a>
</div>


<?php

  include_once('conexao.php');

  $select = '';

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
     $select = $_POST['select'];
 
   

     $sql = "SELECT cod_usuario_oficina,cad_nome,cad_gmail, cad_cnpj, cad_telefone, cad_adm, cad_senha FROM cad_oficina WHERE cod_usuario_oficina ='$select'";
     $result = $conexao->query($sql);

if ($result->num_rows > 0) {
    // Exibe o formulário para cada usuario da oficina
    while ($row = $result->fetch_assoc()) {
        echo '<div class="box">';
        echo '<form action="update_oficina.php" method="post">';
        echo '<fieldset>';

        echo '<legend><b> Atualizar Oficina </b></legend>';
        echo'<br>'; 

        echo '<input type="hidden" name="cod_usuario" value="' . $row['cod_usuario_oficina'] . '">';

        echo '<div class="inputBox">';
        echo '<input class="inputUser" type="text" name="nome" value="' . $row['cad_nome'] . '" required>';
        echo '<label class="labelInput for="nome" class="labelInput">Nome Oficina </label>';
        echo '</div>';
        echo '<br><br>';

        echo '<div class="inputBox">';
        echo '<input class="inputUser" type="text" name="cnpj" value="' . $row['cad_cnpj'] . '" required>';
        echo '<label class="labelInput for="nome" class="labelInput"> CNPJ </label>';
        echo '</div>';
        echo '<br><br>';

        echo '<div class="inputBox">';
        echo '<input class="inputUser" type="text" name="email" value="' . $row['cad_gmail'] . '" required>';
        echo '<label class="labelInput for="email" class="labelInput"> Email </label>';
        echo '</div>';
        echo '<br><br>';


        echo '<div class="inputBox">';
        echo '<input class="inputUser" type="text" name="telefone" value="' . $row['cad_telefone'] . '" required>';
        echo '<label class="labelInput for="nome" class="labelInput">Telefone </label>';
        echo '</div>';
        echo '<br><br>';

        echo '<div class="inputBox">';
        echo '<input class="inputUser" type="text" name="adm" value="' . $row['cad_adm'] . '" required>';
        echo '<label class="labelInput for="nome" class="labelInput">Administrador</label>';
        echo '</div>';
        echo '<br><br>';

        echo '<div class="inputBox">';
        echo '<input class="inputUser" type="text" name="senha" value="' . $row['cad_senha'] . '" required>';
        echo '<label class="labelInput for="nome" class="labelInput">Senha </label>';
        echo '</div>';

        echo '<br><br>';
        echo '<br><br>';
       
        echo '<input class="inputUser" type="submit" id ="submit" value="Atualizar">';
        echo '</fieldset>';
        echo '</form>';
        echo '</div>';
        echo '<br>';
    }
} else {
    echo "Nenhum dado encontrado!.";
}

        exit();

    }
  
?>
</body>
</html>

<DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seleção de Oficina</title>
    <link rel="stylesheet" href="../CSS/select.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>

<div class="icons">
        <a href="../HTML/index_seguradora.html" class="back-button"><i class="bi bi-arrow-return-left"></i></a>
</div>

<div class="box">

<form enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">

<fieldset>

<legend><b> SELECIONE A OFICINA

</b></legend>

<br> 
  
<div class="inputBox"> 
   <select name="select" class="inputUser"> 
   <?php
    $consulta = mysqli_query($conexao, "SELECT cod_usuario_oficina as codigo, cad_nome as nome FROM cad_oficina");

    while ($resultado = mysqli_fetch_array($consulta)) {
      echo "<option value='" . $resultado['codigo'] . "'>" . $resultado['nome'] ."</option>";
    }
   ?>
   </select>
   <label class="labelInput"> NOME: </label>
   </div>

   <br><br>
    <br><br>

   <input type="submit"  id="submit" value="Selecionar">
</fieldset>
</div>
</form>
    
</body>
</html>
