<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <title>Solicitações Respondidas</title>
  
    <style>
        /* ======================= Cards ====================== */
@import url("https://fonts.googleapis.com/css2?family=Ubuntu:wght@300;400;500;700&display=swap");

    body {
    background-image: linear-gradient(to right, rgb(30, 20, 32),#551252);
    padding: 0;
    margin: 0;
    }

    tr.pendente {
        background-color: yellow; /* Amarelo Suave */
    
    }

    tr.aprovado {
        background-color: #60b460 /* Verde Suave */
    }

    tr.reprovado {
        background-color:#c10b0b;
    /* Vermelho Suave */
    }
    .labelPlaca{
        font-family: "Ubutu",sans-serif;
        color: black;
        font-size: 18px;
        font-weight:700;
        
    }

    .submit  {
        background-image: linear-gradient(to right,#591758, #1e081d);
        color: white;
        border: none;
        padding: 5px 20px;
        cursor: pointer;
        border-radius: 3px;
        position: relative;
        left: 8px;
    }

    /* Estilo para os botões no hover */
    .submit:hover {
        background-image: linear-gradient(to right,#1e081d, #591758);

    }
    .placa{
        padding: 5px;
        border-radius: 3px;
        border: 1px solid #ddd;
        margin-bottom: 20px;
    }
    #minhaTabela {
        width: 100%;
        font-family: Roboto;
        font-weight: 600;    
    }

    .total{
        font-family: Roboto,sans-serif;
        font-size: 20px;
        color: #ffffff;
    }

    /* Estilo para o cabeçalho da tabela */
    #minhaTabela th {
        background-color: #591758;
        color: rgb(255, 255, 255);
        padding: 10px;
        text-align: left;
        
    
    }

    /* Estilo para as células da tabela */
    #minhaTabela td {
        padding: 10px;
    }

    #minhaTabela td:hover {
        background-color: #ddd;
    }


    /* Estilo para as linhas de notificações pendentes */
    .pendente {
        background-color: #ffcccb; /* Vermelho claro */
    }

    /* Estilo para as linhas de notificações respondidas */
    .respondido {
        background-color: #ccffcc; /* Verde claro */
    }

    .icons {

        position: absolute;
        /* Define o posicionamento absoluto */
        top: 10px;
        /* Define a distância do topo */
        left: 10px;
        /* Define a distância da esquerda */
        color: #ffffff;
        text-decoration: none;
        font-size: 40px;
        /* Define o tamanho do ícone */
        cursor: pointer;
    }


    .bi-arrow-return-left {
        color: #ffffff;


    }

    .bi-arrow-return-left:hover {
        /*cor de fundo quando  o mouse passa por cima*/
        background-color: #000000;
        color: #721785;
    }

    /* Adiciona um efeito de hover nas linhas da tabela */
    #minhaTabela tr:hover {
    cursor: cell;
    }

    /* Estilo para os links de download */
    #minhaTabela a {
        color: #222428;
        font-weight: bold;
    }

    /* Estilo para os links de download no hover */
    #minhaTabela a:hover {
        color: green;
    }

    /* Estilo para os formulários */
    #minhaTabela form {
        display: inline;
    }

    /* Estilo para os botões */
    #minhaTabela input[type="submit"] {
        background-image: linear-gradient(to right,#591758, #1e081d);
        color: white;
        border: none;
        padding: 5px 10px;
        cursor: pointer;
        border-radius: 3px;
    }

    /* Estilo para os botões no hover */
    #minhaTabela input[type="submit"]:hover {
        background-image: linear-gradient(to right,#1e081d, #591758);

    }

    /* Estilo para os selects */
    #minhaTabela select {
        padding: 5px;
        border-radius: 3px;
        border: 1px solid #ddd;
    }

    .cardBox {
    position: relative;
    width: 95%;
    padding: 20px;
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    grid-gap: 30px;
    font-family: "Ubuntu", sans-serif;
    }

    .cardBox .card {
    position: relative;
    background-color:white;
    padding: 30px;
    border-radius: 20px;
    display: flex;
    justify-content: space-between;
    cursor: pointer;
    box-shadow: 0 7px 25px rgba(0, 0, 0, 0.08);
    }

    .cardBox .card .numbers {
    position: relative;
    font-weight: 500;
    font-size: 2.5rem;
    color:#6e136a;
    }

    .cardBox .card .cardName {
    color: #999;
    font-size: 1.1rem;
    margin-top: 5px;
    }

    .cardBox .card .iconBx {
    font-size: 3.5rem;
    color: #999;
    }
    .cardBox .card:hover {
    background-color:#591758;
    }


    .cardBox .card:hover .numbers,
    .cardBox .card:hover .cardName,
    .cardBox .card:hover .iconBx {
    color: white;
    
    }
    .content{
        position: relative;
        display: flex;
        flex-direction: column;
        justify-content: center;
        min-height: 20px;
        background-color: white;
        padding: 20px;
        box-shadow: 0 7px 25px rgb(0 0 0 / 8%);
        border-radius: 20px;
    }
    .form-filtro{
        margin-bottom: 20px;
    }

/* ====================== Responsive Design card ========================== */
@media (max-width: 991px) {

  .cardBox {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 480px) {
  .cardBox {
    grid-template-columns: repeat(1, 1fr);
  }

}

/* ====================== Responsive Design Table ========================== */
@media (max-width: 768px) {
    #minhaTabela, #minhaTabela thead, #minhaTabela tbody, #minhaTabela th, #minhaTabela td, #minhaTabela tr {
        display: block;
    }

    #minhaTabela thead tr {
        position: absolute;
        top: -9999px;
        left: -9999px;
    }

    #minhaTabela tr {
      
        margin-bottom: 5px;
    }

    #minhaTabela td {
        border: none;
        border-bottom: 1px solid #ddd;
        position: relative;
        padding-left: 50%;
        white-space: normal;
        text-align: left;
    }

    #minhaTabela td:before {
        position: absolute;
        top: 50%;
        left: 10px;
        transform: translateY(-50%);
        width: 45%;
        padding-right: 10px;
        white-space: nowrap;
        font-weight: bold;
    }

    #minhaTabela td:before {
        content: attr(data-label);
    }
}



    </style>
 
</head>

<body>
    <div class = "icons" >
    <a href="../HTML/index_oficina.php" class="back-button"><i class="bi bi-arrow-return-left"></i> </a>
    </div>
    <br><br>    

    <div class="cardBox">
                

                <div class="card">
                    <div>
                    <?php

                    include_once("conexao.php");

                    $count = "SELECT COUNT( cod_res) AS total from resposta";

                    $qtd = $conexao->query($count);

                    if($qtd -> num_rows >0){

                        $objeto = $qtd ->fetch_assoc();
                        echo "<div class='numbers'>";
                        echo $objeto["total"];
                        echo"</div>";
                   

                    }else{
                        echo"Nenhum registro encontrado na tabela!";
                    }

                    ?>
                        
                        <div class="cardName">Total De Solicitações</div>
                    </div>

                    <div class="iconBx">
                    <ion-icon name="stats-chart-outline"></ion-icon>
                    </div>
                </div>

                 <!-- fim primeiro card -->

                <div class="card">
                    <div>

                    <?php

                    include_once("conexao.php");

                    $count = "SELECT COUNT( cod_soli) AS total from solicitacao WHERE status_soli='Pendente'";

                    $qtd = $conexao->query($count);

                    if($qtd -> num_rows >0){

                        $objeto = $qtd ->fetch_assoc();
                        echo "<div class='numbers'>";
                        echo $objeto["total"];
                        echo"</div>";
                   

                    }else{
                        echo"Nenhum registro encontrado na tabela!";
                    }

                    ?>
                        
                        <div class="cardName">Solicitações Pendentes</div>
                    </div>

                    <div class="iconBx">
                    <ion-icon name="warning-outline"></ion-icon>
                    </div>
                </div>

                <!-- fim segundo card -->
                
            <div class="card">
                    <div>
            <?php

                include_once("conexao.php");

                $count = "SELECT COUNT( cod_res) AS total from resposta WHERE resposta='Reprovado'";

                $qtd = $conexao->query($count);

                if($qtd -> num_rows >0){

                    $objeto = $qtd ->fetch_assoc();
                    echo "<div class='numbers'>";
                    echo $objeto["total"];
                    echo"</div>";


                }else{
                    echo"Nenhum registro encontrado na tabela!";
                }

            ?>
                        <div class="cardName">Solicitações Reprovadas</div>
                    </div>

                    <div class="iconBx">
                    <ion-icon name="close-outline"></ion-icon>
                    </div>
                </div>

                <!-- fim terceiro card -->

                <div class="card">
                    <div>
                    <?php

                    include_once("conexao.php");

                    $count = "SELECT COUNT( cod_res) AS total from resposta WHERE resposta='Aprovado'";

                    $qtd = $conexao->query($count);

                    if($qtd -> num_rows >0){

                        $objeto = $qtd ->fetch_assoc();
                        echo "<div class='numbers'>";
                        echo $objeto["total"];
                        echo"</div>";


                    }else{
                        echo"Nenhum registro encontrado na tabela!";
                    }

                    ?>
                        <div class="cardName">Solicitações Aprovadas</div>
                    </div>

                    <div class="iconBx">
                    <ion-icon name="checkmark-outline"></ion-icon>
                    </div>
                </div>
            </div>
    






<?php

include_once("conexao.php");


echo'<div class="content">';
echo'<form action="filtro_res.php" method="post">';

$filtro = "SELECT cad_veiculos.placa_veiculo AS placa,resposta.cod_veiculo as codigo_veiculo  
FROM resposta INNER JOIN cad_veiculos ON cad_veiculos.cod_veiculo = resposta.cod_veiculo";

$consulta = mysqli_query($conexao, $filtro);

echo '<label class="labelPlaca"> Placa: </label>';
echo '<select name="placa" class="placa">';
        while ($resultadoVeiculo = mysqli_fetch_array($consulta)) {
            echo "<option value='" . $resultadoVeiculo['codigo_veiculo'] . "'>" . $resultadoVeiculo['placa'] . "</option>";
        }
echo '</select>';


echo'<input type="submit" class="submit" value="Filtrar">';

echo'</form>';


$sql = "SELECT cod_res,resposta, resposta.cod_veiculo AS codigo_veiculo,
        DATE_FORMAT(data_res,'%d/%m/%Y') AS data_res,marca_veiculo,
        modelo_veiculo,placa_veiculo
        FROM resposta
        INNER JOIN cad_veiculos ON cad_veiculos.cod_veiculo = resposta.cod_veiculo";




$result = $conexao->query($sql);

if ($result->num_rows > 0) {

   
    // Cria a tabela HTML
   // Cria a tabela HTML
        echo "<table border='1' id='minhaTabela' class='table'>";

        echo "<tr>";
        echo "<th>Código Resposta</th>";
        echo "<th>Status</th>";
        echo "<th>Data</th>";
        echo "<th>Marca do Veículo</th>";
        echo "<th>Modelo do Veículo</th>";
        echo "<th>Placa do Veículo</th>";
        echo "</tr>";

// Exibe os dados em cada linha da tabela
while($row = $result->fetch_assoc()) {
    $codigo_veiculo = $row["codigo_veiculo"];
    $status = $row["resposta"];

    if($status == 'Pendente'){

        echo "<tr class='pendente'>";

    }else if($status =='Aprovado'){
        echo "<tr class='aprovado'>";
    }else if($status == 'Reprovado'){
        echo "<tr class='reprovado'>";
    }
   

   
    echo "<td>" . $row["cod_res"] . "</td>";
    echo "<td>" . $row["resposta"] . "</td>";
    echo "<td>" . $row["data_res"] . "</td>";
    echo "<td>" . $row["marca_veiculo"] . "</td>";
    echo "<td>" . $row["modelo_veiculo"] . "</td>";
    echo "<td>" . $row["placa_veiculo"] . "</td>";

    echo "</tr>";

}




$sql_soli = "SELECT cod_soli,status_soli, solicitacao.cod_veiculo AS codigo_veiculo, 
DATE_FORMAT(data_soli,'%d/%m/%Y') AS data_soli,marca_veiculo, modelo_veiculo,placa_veiculo
FROM solicitacao
INNER JOIN cad_veiculos ON cad_veiculos.cod_veiculo = solicitacao.cod_veiculo
WHERE status_soli ='Pendente'";

$result_soli = mysqli_query($conexao,$sql_soli);

if($result_soli -> num_rows > 0 ){
while($linha = $result_soli ->fetch_assoc()){

echo "<tr class='pendente'>";

echo "<td>" . $linha["cod_soli"] . "</td>";
echo "<td>" . $linha["status_soli"] . "</td>";
echo "<td>" . $linha["data_soli"] . "</td>";
echo "<td>" . $linha["marca_veiculo"] . "</td>";
echo "<td>" . $linha["modelo_veiculo"] . "</td>";
echo "<td>" . $linha["placa_veiculo"] . "</td>";
echo "</tr>";


}
}



echo "</table>";
echo'<div class="content">';


}

?>

    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>
</html>
