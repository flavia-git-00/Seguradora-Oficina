<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Atualizando Oficina...</title>
        <style>
        /* Estilo para centralizar o indicador de carregamento */
        .loading-container {
            background-image: linear-gradient(to right, rgb(30, 20, 32),#551252);
            display: flex;
            justify-content: center;
            align-items: center;
            position: fixed;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: black;
            z-index: 9999;
        }

        .loading-container img {
            border-radius:15px;
            width:600px;
            height: 400px;
        }
    </style>
    </head>
<body>

<div class="loading-container">
    <img src="../GIF/upload.gif" alt="Carregando...">
</div>

<!-- Seu conteúdo HTML principal (será exibido após o carregamento) -->
<div id="content" style="display:none;">

    
    <?php

    include_once("conexao.php");

    $cod_usuario = $_POST['cod_usuario'];
    $nome = $_POST['nome'];
    $cnpj = $_POST['cnpj'];
    $telefone = $_POST['telefone'];
    $adm = $_POST['adm'];
    $senha = $_POST['senha'];
    $email = $_POST['email'];


    $update = "UPDATE cad_oficina SET cad_nome ='$nome',
    cad_gmail = '$email',
    cad_cnpj = '$cnpj',
    cad_telefone = '$telefone',
    cad_adm = '$adm',
    cad_senha = '$senha'
    WHERE cod_usuario_oficina = '$cod_usuario'";

    $resultado = mysqli_query($conexao,$update);


    if($resultado){
        echo '<script type="text/javascript">';
        echo 'document.getElementById("content").style.display = "block";'; // Exibe o conteúdo principal
        echo 'setTimeout(function() { window.location.href = "../PHP/atualizar.php"; }, 5000);'; // Redireciona após 3 segundos
        echo '</script>';
    } else {
        echo "OCORREU UM ERRO AO ATUALIZAR O USUARIO!" . mysqli_error($conexao);
        exit();
    }
    ?>

</div>

<script>
    // Exibir o conteúdo principal após o carregamento completo da página
    window.onload = function() {
        document.getElementById('content').style.display = 'block';
    };
</script>

    
</body>
</html>