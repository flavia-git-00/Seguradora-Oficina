<?php
// Inclua a biblioteca FPDF
require('fpdf186/fpdf.php');
include_once('conexao.php');

// Verifique se os dados do formulário foram enviados
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Captura os dados do formulário
   
 // Crie um novo objeto FPDF
$pdf = new FPDF();
$pdf->AddPage();

$modelo = $_POST['modelo'];
$marca = $_POST['marca'];
$placa =$_POST['placa'];
$cod_imagem = $_POST['codigo_imagem_chassi'];
$orc_chassi = $_POST['orc_chassi'];
$desc_chassi=$_POST['desc_chassi'];
$codigo_veiculo = $_POST['codigo_veiculo_CH'];

 // Defina a codificação de caracteres como UTF-8
// Adicionar o título (Orçamento do Veículo)
$pdf->SetFont('Arial', '', 28);
$pdf->MultiCell(0, 15, utf8_decode("Orçamento do Veículo: " . ($modelo)), 0, 'C', false);
$pdf->SetY($pdf->GetY() + 5);

// CELL(22,0) o espaçamento entre o texto da mesma linha
// CELL (0,0) define se o texto vai quebrar para proxima linha ou não
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(22, 10, utf8_decode("MARCA:"), 0, 0, '');

$pdf->SetFont('Arial', '', 14);
$pdf->Cell(0, 10, utf8_decode("$marca"), 0, 1, 'E');

$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(24, 10, utf8_decode("MODELO:"), 0, 0, '');

$pdf->SetFont('Arial', '', 14);
$pdf->Cell(0, 10, utf8_decode("$modelo"), 0, 1, 'E');

$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(22, 10, utf8_decode("PLACA:"), 0, 0, '');

$pdf->SetFont('Arial', '', 14);
$pdf->Cell(0, 10, utf8_decode("$placa"), 0, 1, 'E');

//o eixo Y define que o próximo texto que vira abaixo terá um espaçamento maior
$pdf->SetY($pdf->GetY() + 1);

$pdf->SetFillColor(0, 0, 0); // PRETO
//cria o retangulo amarelo
$pdf->Rect(10, $pdf->GetY() + 1, 190, 9, 'F');
$pdf->SetFont('Arial', '', 14);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell(0, 10, utf8_decode("CHASSI:"), 0, 1, 'C');
$pdf->SetTextColor(0, 0, 0); // R, G, B: todos 0 para preto


$pdf->SetY($pdf->GetY() + 20);


// Consulta SQL para obter o nome do arquivo da imagem CHASSI

$sql = "SELECT imagem, nome_imagem FROM imagens WHERE cod_imagem = '$cod_imagem'";
$stmt = $conexao->prepare($sql);
$stmt->execute();
$stmt->bind_result($imagemBlob, $nomeImagem);
$stmt->fetch();
$stmt->free_result();

// Se o nome do arquivo e a imagem foram recuperados com sucesso
if ($nomeImagem && $imagemBlob) {
    // Crie um arquivo temporário para armazenar a imagem
    $tempFile = tempnam(sys_get_temp_dir(), 'image') . '.png' . '.jpeg';
    $imageInfo = getimagesizefromstring($imagemBlob);
    $imageType = $imageInfo[2];

    if ($imageType === IMAGETYPE_JPEG) {
        $tempFile .= '.jpg';
    } elseif ($imageType === IMAGETYPE_PNG) {
        $tempFile .= '.png';
    } else {
        // Se o tipo da imagem não for suportado, você pode adicionar uma extensão padrão
        $tempFile .= '.jpg'; // Ou .png, dependendo da sua preferência
    }

    file_put_contents($tempFile, $imagemBlob);

    // Adicione a imagem ao PDF
    $pdf->Image($tempFile, 75, 90, 60, 60, "");

    $posicaoY = 100 + 50 + 2; // Altura da imagem (30) + Espaçamento adicional (10)

// Defina a nova posição Y para os próximos elementos
    $pdf->SetY($posicaoY);

    // Exclua o arquivo temporário
    unlink($tempFile);
} else {
    echo "Imagem não encontrada no banco de dados.";
}

// Antes de executar a nova consulta, limpe o statement da consulta anterior
$stmt->close();

$pdf->SetFont('Arial', '', 14);
$pdf->Cell(0, 10, utf8_decode("VALOR: R$ $orc_chassi"), 0, 1, 'C');
$pdf->MultiCell(0, 8, utf8_decode("DESCRIÇÃO:" . ($desc_chassi)), 0, 'C', false);


$pdf->SetY($pdf->GetY() + 5);


$pdf->SetFillColor(255, 255, 0); // Amarelo

$pdf->SetFillColor(0, 0, 0); // PRETO
//cria o retangulo amarelo
$pdf->Rect(10, $pdf->GetY() + 1, 190, 9, 'F');
$pdf->SetFont('Arial', '', 14);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell(0, 10, utf8_decode("HODÔMETRO:"), 0, 1, 'C');
$pdf->SetTextColor(0, 0, 0); // R, G, B: todos 0 para preto
$pdf->SetY($pdf->GetY() + 20);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// CODIGO DO HODOMETRO SE INICIA AQUI!


$codigo_hodometro=$_POST['codigo_hodometro'];
$orc_hodometro=$_POST['orc_hodometro'];
$desc_hodometro=$_POST['desc_hodometro'];



$sql_H = "SELECT imagem_hodometro, nome_imagem_hodometro FROM imagens_hodometro WHERE cod_imagem_hodometro = '$codigo_hodometro'";
$stmt_H = $conexao->prepare($sql_H);
$stmt_H->execute();
$stmt_H->bind_result($imagemBlob_H, $nomeImagem_H);
$stmt_H->fetch();
$stmt_H->free_result();


if ($nomeImagem_H && $imagemBlob_H) {
    // Crie um arquivo temporário para armazenar a imagem
    $tempFile_H = tempnam(sys_get_temp_dir(), 'imagem') . '.png' . '.jpeg';
    $imageInfo_H = getimagesizefromstring($imagemBlob_H);
    $imageType_H = $imageInfo_H[2];

    if ($imageType_H === IMAGETYPE_JPEG) {
        $tempFile_H .= '.jpg';
    } elseif ($imageType_H === IMAGETYPE_PNG) {
        $tempFile_H .= '.png';
    } else {
        // Se o tipo da imagem não for suportado, você pode adicionar uma extensão padrão
        $tempFile_H .= '.jpg'; // Ou .png, dependendo da sua preferência
    }

    file_put_contents($tempFile_H, $imagemBlob_H);

    // Adicione a imagem ao PDF
    $pdf->Image($tempFile_H, 75, 190, 60, 60, "");

    $posicaoY_H = 260 + 30 + 2; // Altura da imagem (30) + Espaçamento adicional (10)

// Defina a nova posição Y para os próximos elementos
$pdf->SetY($posicaoY_H);

    // Exclua o arquivo temporário
    unlink($tempFile_H);
} else {
    echo "Imagem não encontrada no banco de dados.";
}

// Feche a conexão com o banco de dados

$stmt_H->close();



$pdf->SetFont('Arial', '', 14);
$pdf->Cell(0, 10, utf8_decode("VALOR: R$ $orc_hodometro"), 0, 1, 'C');
$pdf->MultiCell(0, 8, utf8_decode("DESCRIÇÃO:" . ($desc_hodometro)), 0, 'C', false);

$pdf->SetY($pdf->GetY() + 8);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// CODIGO DO FRENTE SE INICIA AQUI!

$codigo_frente = $_POST['codigo_frente'];
$orc_frente=  $_POST['orc_frente'];
$desc_frente = $_POST['desc_frente'];


$pdf->SetFillColor(0, 0, 0); // PRETO
//cria o retangulo amarelo
$pdf->Rect(10, $pdf->GetY() + 1, 190, 9, 'F');
$pdf->SetFont('Arial', '', 14);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell(0, 10, utf8_decode("FRENTE:"), 0, 1, 'C');
$pdf->SetTextColor(0, 0, 0); // R, G, B: todos 0 para preto



$sql_F = "SELECT imagem_frente, nome_imagem_frente FROM imagens_frente WHERE cod_imagem_frente = '$codigo_frente'";
$stmt_F = $conexao->prepare($sql_F);
$stmt_F->execute();
$stmt_F->bind_result($imagemBlob_F, $nomeImagem_F);
$stmt_F->fetch();
$stmt_F->free_result();


if ($nomeImagem_F && $imagemBlob_F) {
    // Crie um arquivo temporário para armazenar a imagem
    $tempFile_F = tempnam(sys_get_temp_dir(), 'imagem_F') . '.png' . '.jpeg';
    $imageInfo_F = getimagesizefromstring($imagemBlob_F);
    $imageType_F = $imageInfo_F[2];

    if ($imageType_F === IMAGETYPE_JPEG) {
        $tempFile_F .= '.jpg';
    } elseif ($imageType_F=== IMAGETYPE_PNG) {
        $tempFile_F .= '.png';
    } else {
        // Se o tipo da imagem não for suportado, você pode adicionar uma extensão padrão
        $tempFile_F .= '.jpg'; // Ou .png, dependendo da sua preferência
    }

    file_put_contents($tempFile_F, $imagemBlob_F);

    // Adicione a imagem ao PDF
    $pdf->Image($tempFile_F, 75, 50, 60, 60, "");

    $posicaoY_F = 80 + 30 + 2; // Altura da imagem (30) + Espaçamento adicional (10)

// Defina a nova posição Y para os próximos elementos
    $pdf->SetY($posicaoY_F);

    // Exclua o arquivo temporário
    unlink($tempFile_F);
} else {
    echo "Imagem não encontrada no banco de dados.";
}

// Feche a conexão com o banco de dados

$stmt_F->close();

$pdf->SetFont('Arial', '', 14);
$pdf->Cell(0, 10, utf8_decode("VALOR: R$ $orc_frente"), 0, 1, 'C');
$pdf->MultiCell(0, 8, utf8_decode("DESCRIÇÃO:" . ($desc_frente)), 0, 'C', false);

/////////////////////////////////////////////////////////////////////////////////////////////////////////
$pdf->SetY($pdf->GetY() + 10);

// CODIGO DO FRENTE SE TRASEIRA SE INICIA AQUI!

$codigo_traseira = $_POST['codigo_traseira'];
$orc_traseira=  $_POST['orc_traseira'];
$desc_traseira = $_POST['desc_traseira'];

$pdf->SetFillColor(0, 0, 0); // PRETO
//cria o retangulo amarelo
$pdf->Rect(10, $pdf->GetY() + 1, 190, 9, 'F');
$pdf->SetFont('Arial', '', 14);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell(0, 10, utf8_decode("TRASEIRA:"), 0, 1, 'C');
$pdf->SetTextColor(0, 0, 0); // R, G, B: todos 0 para preto


$sql_T = "SELECT imagem_traseira, nome_imagem_traseira FROM imagens_traseira WHERE cod_imagem_traseira = '$codigo_traseira'";
$stmt_T = $conexao->prepare($sql_T);
$stmt_T->execute();
$stmt_T->bind_result($imagemBlob_T, $nomeImagem_T);
$stmt_T->fetch();
$stmt_T->free_result();


if ($nomeImagem_T && $imagemBlob_T) {
    // Crie um arquivo temporário para armazenar a imagem
    $tempFile_T = tempnam(sys_get_temp_dir(), 'imagem_T') . '.png' . '.jpeg';
    $imageInfo_T = getimagesizefromstring($imagemBlob_T);
    $imageType_T = $imageInfo_T[2];

    if ($imageType_T === IMAGETYPE_JPEG) {
        $tempFile_T .= '.jpg';
    } elseif ($imageType_T=== IMAGETYPE_PNG) {
        $tempFile_T .= '.png';
    } else {
      // Se o tipo da imagem não for suportado, você pode adicionar uma extensão padrão
        $tempFile_T .= '.jpg'; // Ou .png, dependendo da sua preferência
    }

    file_put_contents($tempFile_T, $imagemBlob_T);

    // Adicione a imagem ao PDF
    $pdf->Image($tempFile_T, 75, 155, 60, 60, "");

    $posicaoY_T = 190 + 30 + 2; // Altura da imagem (30) + Espaçamento adicional (10)

// Defina a nova posição Y para os próximos elementos
    $pdf->SetY($posicaoY_T);

    // Exclua o arquivo temporário
    unlink($tempFile_T);
} else {
    echo "Imagem não encontrada no banco de dados.";
}

// Feche a conexão com o banco de dados

$stmt_T->close();

$pdf->SetFont('Arial', '', 14);
$pdf->Cell(0, 10, utf8_decode("VALOR: R$ $orc_traseira"), 0, 1, 'C');
$pdf->MultiCell(0, 8, utf8_decode("DESCRIÇÃO:" . ($desc_traseira)), 0, 'C', false);
$pdf->AddPage();
/////////////////////////////////////////////////////////////////////////////////////////////////////////
$pdf->SetY($pdf->GetY() + 5);
// CODIGO DO LATERAL DIREITA SE INICIA AQUI!

$codigo_latdireita = $_POST['codigo_latdireita'];
$orc_latdireita=  $_POST['orc_latdireita'];
$desc_latdireita = $_POST['desc_latdireita'];


$pdf->SetFillColor(0, 0, 0); // PRETO
//cria o retangulo amarelo
$pdf->Rect(10, $pdf->GetY() + 1, 190, 9, 'F');
$pdf->SetFont('Arial', '', 14);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell(0, 10, utf8_decode("LATERAL DIREITA:"), 0, 1, 'C');
$pdf->SetTextColor(0, 0, 0); // R, G, B: todos 0 para preto

$sql_LD = "SELECT imagem_latdireita, nome_imagem_latdireita FROM imagens_latdireita WHERE cod_imagem_latdireita = '$codigo_latdireita'";
$stmt_LD = $conexao->prepare($sql_LD);
$stmt_LD->execute();
$stmt_LD->bind_result($imagemBlob_LD, $nomeImagem_LD);
$stmt_LD->fetch();
$stmt_LD->free_result();


if ($nomeImagem_LD && $imagemBlob_LD) {
    // Crie um arquivo temporário para armazenar a imagem
    $tempFile_LD = tempnam(sys_get_temp_dir(), 'imagem_LD') . '.png' . '.jpeg';
    $imageInfo_LD = getimagesizefromstring($imagemBlob_LD);
    $imageType_LD = $imageInfo_LD[2];

    if ($imageType_LD === IMAGETYPE_JPEG) {
        $tempFile_LD .= '.jpg';
    } elseif ($imageType_LD=== IMAGETYPE_PNG) {
        $tempFile_LD .= '.png';
    } else {
        // Se o tipo da imagem não for suportado, você pode adicionar uma extensão padrão
        $tempFile_LD .= '.jpg'; // Ou .png, dependendo da sua preferência
    }

    file_put_contents($tempFile_LD, $imagemBlob_LD);

    // Adicione a imagem ao PDF
    $pdf->Image($tempFile_LD, 75, 28, 60, 60, "");

    $posicaoY_LD = 60 + 30 + 2; // Altura da imagem (30) + Espaçamento adicional (10)

    $pdf->SetY($posicaoY_LD);

    // Exclua o arquivo temporário
    unlink($tempFile_LD);
} else {
    echo "Imagem não encontrada no banco de dados.";
}

// Feche a conexão com o banco de dados

$stmt_LD->close();

$pdf->SetFont('Arial', '', 14);
$pdf->Cell(0, 10, utf8_decode("VALOR: R$ $orc_latdireita"), 0, 1, 'C');
$pdf->MultiCell(0, 8, utf8_decode("DESCRIÇÃO:" . ($desc_latdireita)), 0, 'C', false);



////////////////////////////////////////////////////////////////////////////////////////////////////////
$pdf->SetY($pdf->GetY() + 10);
// CODIGO DO LATERAL ESQUERDA SE INICIA AQUI!

$codigo_latesquerda = $_POST['codigo_latesquerda'];
$orc_latesquerda=  $_POST['orc_latesquerda'];
$desc_latesquerda = $_POST['desc_latesquerda'];


$pdf->SetFillColor(0, 0, 0); // PRETO
//cria o retangulo amarelo
$pdf->Rect(10, $pdf->GetY() + 1, 190, 9, 'F');
$pdf->SetFont('Arial', '', 14);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell(0, 10, utf8_decode("LATERAL ESQUERDA:"), 0, 1, 'C');
$pdf->SetTextColor(0, 0, 0); // R, G, B: todos 0 para preto

$sql_LE = "SELECT imagem_latesquerda, nome_imagem_latesquerda FROM imagens_latesquerda WHERE cod_imagem_latesquerda = '$codigo_latesquerda'";
$stmt_LE = $conexao->prepare($sql_LE);
$stmt_LE->execute();
$stmt_LE->bind_result($imagemBlob_LE, $nomeImagem_LE);
$stmt_LE->fetch();
$stmt_LE->free_result();


if ($nomeImagem_LE && $imagemBlob_LE) {
    // Crie um arquivo temporário para armazenar a imagem
    $tempFile_LE = tempnam(sys_get_temp_dir(), 'imagem_LE') . '.png' . '.jpeg';
    $imageInfo_LE = getimagesizefromstring($imagemBlob_LE);
    $imageType_LE = $imageInfo_LE[2];

    if ($imageType_LE === IMAGETYPE_JPEG) {
        $tempFile_LE .= '.jpg';
    } elseif ($imageType_LE=== IMAGETYPE_PNG) {
        $tempFile_LE .= '.png';
    } else {
        // Se o tipo da imagem não for suportado, você pode adicionar uma extensão padrão
        $tempFile_LE .= '.jpg'; // Ou .png, dependendo da sua preferência
    }

    file_put_contents($tempFile_LE, $imagemBlob_LD);

    // Adicione a imagem ao PDF
    $pdf->Image($tempFile_LE, 75, 133, 60, 60, "");

    $posicaoY_LE = 165 + 30 + 2; // Altura da imagem (30) + Espaçamento adicional (10)


  
    $pdf->SetY($posicaoY_LE);

    // Exclua o arquivo temporário
    unlink($tempFile_LE);
} else {
    echo "Imagem não encontrada no banco de dados.";
}

// Feche a conexão com o banco de dados

$stmt_LE->close();

$pdf->SetFont('Arial', '', 14);
$pdf->Cell(0, 10, utf8_decode("VALOR: R$ $orc_latesquerda"), 0, 1, 'C');
$pdf->MultiCell(0, 8, utf8_decode("DESCRIÇÃO:" . ($desc_latesquerda)), 0, 'C', false);

$pdf->AddPage();

////////////////////////////////////////////////////////////////////////////////////////////////////////
$pdf->SetY($pdf->GetY() + 3);
// CODIGO DO CAPO SE INICIA AQUI!


$codigo_capo = $_POST['codigo_capo'];
$orc_capo=  $_POST['orc_capo'];
$desc_capo = $_POST['desc_capo'];


$pdf->SetFillColor(0, 0, 0); // PRETO
//cria o retangulo amarelo
$pdf->Rect(10, $pdf->GetY() + 1, 190, 9, 'F');
$pdf->SetFont('Arial', '', 14);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell(0, 10, utf8_decode("CAPÔ ABERTO:"), 0, 1, 'C');
$pdf->SetTextColor(0, 0, 0); // R, G, B: todos 0 para preto

$sql_C = "SELECT imagem_capo, nome_imagem_capo FROM imagens_capo WHERE cod_imagem_capo = '$codigo_capo'";
$stmt_C = $conexao->prepare($sql_C);
$stmt_C->execute();
$stmt_C->bind_result($imagemBlob_C, $nomeImagem_C);
$stmt_C->fetch();
$stmt_C->free_result();


if ($nomeImagem_C && $imagemBlob_C) {
    // Crie um arquivo temporário para armazenar a imagem
    $tempFile_C = tempnam(sys_get_temp_dir(), 'imagem_C') . '.png' . '.jpeg';
    $imageInfo_C = getimagesizefromstring($imagemBlob_C);
    $imageType_C = $imageInfo_C[2];

    if ($imageType_C === IMAGETYPE_JPEG) {
        $tempFile_C .= '.jpg';
    } elseif ($imageType_C=== IMAGETYPE_PNG) {
        $tempFile_C .= '.png';
    } else {
        // Se o tipo da imagem não for suportado, você pode adicionar uma extensão padrão
        $tempFile_C .= '.jpg'; // Ou .png, dependendo da sua preferência
    }

    file_put_contents($tempFile_C, $imagemBlob_C);

    // Adicione a imagem ao PDF
    $pdf->Image($tempFile_C, 75, 28, 60, 60, "");

    $posicaoY_C = 60 + 30 + 2; // Altura da imagem (30) + Espaçamento adicional (10)

    $pdf->SetY($posicaoY_C);

    // Exclua o arquivo temporário
    unlink($tempFile_C);
} else {
    echo "Imagem não encontrada no banco de dados.";
}

// Feche a conexão com o banco de dados

$stmt_C->close();

$pdf->SetFont('Arial', '', 14);
$pdf->Cell(0, 10, utf8_decode("VALOR: R$ $orc_capo"), 0, 1, 'C');
$pdf->MultiCell(0, 8, utf8_decode("DESCRIÇÃO:" . ($desc_capo)), 0, 'C', false);



////////////////////////////////////////////////////////////////////////////////////////////////////////
$pdf->SetY($pdf->GetY() + 10);
// CODIGO DAS PEÇAS DANIFICADAS SE INICIA AQUI!

$codigo_pecas = $_POST['codigo_pecas'];
$orc_pecas=  $_POST['orc_pecas'];
$desc_pecas = $_POST['desc_pecas'];


$pdf->SetFillColor(0, 0, 0); // PRETO
//cria o retangulo amarelo
$pdf->Rect(10, $pdf->GetY() + 1, 190, 9, 'F');
$pdf->SetFont('Arial', '', 14);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell(0, 10, utf8_decode("PEÇAS DANIFICADAS:"), 0, 1, 'C');
$pdf->SetTextColor(0, 0, 0); // R, G, B: todos 0 para preto

$sql_P = "SELECT imagem_pecas, nome_imagem_pecas FROM imagens_pecas WHERE cod_imagem_pecas = '$codigo_pecas'";
$stmt_P = $conexao->prepare($sql_P);
$stmt_P->execute();
$stmt_P->bind_result($imagemBlob_P, $nomeImagem_P);
$stmt_P->fetch();
$stmt_P->free_result();


if ($nomeImagem_P && $imagemBlob_P) {
    // Crie um arquivo temporário para armazenar a imagem
    $tempFile_P = tempnam(sys_get_temp_dir(), 'imagem_P') . '.png' . '.jpeg';
    $imageInfo_P = getimagesizefromstring($imagemBlob_P);
    $imageType_P = $imageInfo_P[2];

    if ($imageType_P === IMAGETYPE_JPEG) {
        $tempFile_P .= '.jpg';
    } elseif ($imageType_P=== IMAGETYPE_PNG) {
        $tempFile_P .= '.png';
    } else {
        // Se o tipo da imagem não for suportado, você pode adicionar uma extensão padrão
        $tempFile_P .= '.jpg'; // Ou .png, dependendo da sua preferência
    }

    file_put_contents($tempFile_P, $imagemBlob_P);

    // Adicione a imagem ao PDF
    $pdf->Image($tempFile_P, 75, 135, 60, 60, "");

    $posicaoY_P = 170 + 30 + 2; // Altura da imagem (30) + Espaçamento adicional (10)


  
    $pdf->SetY($posicaoY_P);

    // Exclua o arquivo temporário
    unlink($tempFile_P);
} else {
    echo "Imagem não encontrada no banco de dados.";
}

// Feche a conexão com o banco de dados

$stmt_P->close();

$pdf->SetFont('Arial', '', 14);
$pdf->Cell(0, 10, utf8_decode("VALOR: R$ $orc_pecas"), 0, 1, 'C');
$pdf->MultiCell(0, 8, utf8_decode("DESCRIÇÃO:" . ($desc_pecas)), 0, 'C', false);

$conexao->close();
// Defina o nome do arquivo PDF
$filename = "orcamento_veiculo.pdf";

// Saída do PDF
$pdf->Output($filename, 'D');
exit;

}
?>
