<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    
    <title>Filtro</title>
    <style>
        /* ======================= Cards ====================== */
@import url("https://fonts.googleapis.com/css2?family=Ubuntu:wght@300;400;500;700&display=swap");

    body {
    background-image: linear-gradient(to right, rgb(30, 20, 32),#551252);
    padding: 0;
    margin: 0;
    }

    tr.pendente {
        background-color: yellow; /* Amarelo Suave */
    
    }

    tr.aprovado {
        background-color: #60b460 /* Verde Suave */
    }

    tr.reprovado {
        background-color:#c10b0b;
    /* Vermelho Suave */
    }
    .labelPlaca{
        font-family: "Ubutu",sans-serif;
        color: black;
        font-size: 18px;
        font-weight:700;
        
    }

    .submit  {
        background-image: linear-gradient(to right,#591758, #1e081d);
        color: white;
        border: none;
        padding: 5px 20px;
        cursor: pointer;
        border-radius: 3px;
        position: relative;
        left: 8px;
    }

    /* Estilo para os botões no hover */
    .submit:hover {
        background-image: linear-gradient(to right,#1e081d, #591758);

    }
    .placa{
        padding: 5px;
        border-radius: 3px;
        border: 1px solid #ddd;
    }
    #minhaTabela {
        width: 100%;
        font-family: Roboto;
        font-weight: 600;    
    }

    .total{
        font-family: Roboto,sans-serif;
        font-size: 20px;
        color: #ffffff;
    }

    /* Estilo para o cabeçalho da tabela */
    #minhaTabela th {
        background-color: #591758;
        color: rgb(255, 255, 255);
        padding: 10px;
        text-align: left;
        
    
    }

    /* Estilo para as células da tabela */
    #minhaTabela td {
        padding: 10px;
    }

    #minhaTabela td:hover {
        background-color: #ddd;
    }


    /* Estilo para as linhas de notificações pendentes */
    .pendente {
        background-color: #ffcccb; /* Vermelho claro */
    }

    /* Estilo para as linhas de notificações respondidas */
    .respondido {
        background-color: #ccffcc; /* Verde claro */
    }

    .icons {

        position: absolute;
        /* Define o posicionamento absoluto */
        top: 10px;
        /* Define a distância do topo */
        left: 10px;
        /* Define a distância da esquerda */
        color: #ffffff;
        text-decoration: none;
        font-size: 40px;
        /* Define o tamanho do ícone */
        cursor: pointer;
    }


    .bi-arrow-return-left {
        color: #ffffff;


    }

    .bi-arrow-return-left:hover {
        /*cor de fundo quando  o mouse passa por cima*/
        background-color: #000000;
        color: #721785;
    }

    /* Adiciona um efeito de hover nas linhas da tabela */
    #minhaTabela tr:hover {
    cursor: cell;
    }

    /* Estilo para os links de download */
    #minhaTabela a {
        color: #222428;
        font-weight: bold;
    }

    /* Estilo para os links de download no hover */
    #minhaTabela a:hover {
        color: green;
    }

    /* Estilo para os formulários */
    #minhaTabela form {
        display: inline;
    }

    /* Estilo para os botões */
    #minhaTabela input[type="submit"] {
        background-image: linear-gradient(to right,#591758, #1e081d);
        color: white;
        border: none;
        padding: 5px 10px;
        cursor: pointer;
        border-radius: 3px;
    }

    /* Estilo para os botões no hover */
    #minhaTabela input[type="submit"]:hover {
        background-image: linear-gradient(to right,#1e081d, #591758);

    }

    /* Estilo para os selects */
    #minhaTabela select {
        padding: 5px;
        border-radius: 3px;
        border: 1px solid #ddd;
    }

    .cardBox {
    position: relative;
    width: 95%;
    padding: 20px;
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    grid-gap: 30px;
    font-family: "Ubuntu", sans-serif;
    }

    .cardBox .card {
    position: relative;
    background-color:white;
    padding: 30px;
    border-radius: 20px;
    display: flex;
    justify-content: space-between;
    cursor: pointer;
    box-shadow: 0 7px 25px rgba(0, 0, 0, 0.08);
    }

    .cardBox .card .numbers {
    position: relative;
    font-weight: 500;
    font-size: 2.5rem;
    color:#6e136a;
    }

    .cardBox .card .cardName {
    color: #999;
    font-size: 1.1rem;
    margin-top: 5px;
    }

    .cardBox .card .iconBx {
    font-size: 3.5rem;
    color: #999;
    }
    .cardBox .card:hover {
    background-color:#591758;
    }


    .cardBox .card:hover .numbers,
    .cardBox .card:hover .cardName,
    .cardBox .card:hover .iconBx {
    color: white;
    
    }
    .content{
        position: relative;
        display: flex;
        flex-direction: column;
        justify-content: center;
        min-height: 300px;
        background-color: white;
        padding: 20px;
        box-shadow: 0 7px 25px rgb(0 0 0 / 8%);
        border-radius: 20px;
    }
    .form-filtro{
        margin-bottom: 20px;
    }

/* ====================== Responsive Design card ========================== */
@media (max-width: 991px) {

  .cardBox {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 480px) {
  .cardBox {
    grid-template-columns: repeat(1, 1fr);
  }

}

/* ====================== Responsive Design Table ========================== */
@media (max-width: 768px) {
    #minhaTabela, #minhaTabela thead, #minhaTabela tbody, #minhaTabela th, #minhaTabela td, #minhaTabela tr {
        display: block;
    }

    #minhaTabela thead tr {
        position: absolute;
        top: -9999px;
        left: -9999px;
    }

    #minhaTabela tr {
      
        margin-bottom: 5px;
    }

    #minhaTabela td {
        border: none;
        border-bottom: 1px solid #ddd;
        position: relative;
        padding-left: 50%;
        white-space: normal;
        text-align: left;
    }

    #minhaTabela td:before {
        position: absolute;
        top: 50%;
        left: 10px;
        transform: translateY(-50%);
        width: 45%;
        padding-right: 10px;
        white-space: nowrap;
        font-weight: bold;
    }

    #minhaTabela td:before {
        content: attr(data-label);
    }
}



    </style>
 
 
</head>

<body>
    
    <div class = "icons" >
    <a href="responder.php" class="back-button"><i class="bi bi-arrow-return-left"></i> </a>
    </div>
<br><br>





<div class="cardBox">
                

                <div class="card">
                    <div>
                    <?php

                    include_once("conexao.php");

                    $count = "SELECT COUNT( cod_soli) AS total from solicitacao";

                    $qtd = $conexao->query($count);

                    if($qtd -> num_rows >0){

                        $objeto = $qtd ->fetch_assoc();
                        echo "<div class='numbers'>";
                        echo $objeto["total"];
                        echo"</div>";
                   

                    }else{
                        echo"Nenhum registro encontrado na tabela!";
                    }

                    ?>
                        
                        <div class="cardName">Total De Solicitações</div>
                    </div>

                    <div class="iconBx">
                    <ion-icon name="stats-chart-outline"></ion-icon>
                    </div>
                </div>

                 <!-- fim primeiro card -->

                <div class="card">
                    <div>

                    <?php

                    include_once("conexao.php");

                    $count = "SELECT COUNT( cod_soli) AS total from solicitacao WHERE status_soli='Pendente'";

                    $qtd = $conexao->query($count);

                    if($qtd -> num_rows >0){

                        $objeto = $qtd ->fetch_assoc();
                        echo "<div class='numbers'>";
                        echo $objeto["total"];
                        echo"</div>";
                   

                    }else{
                        echo"Nenhum registro encontrado na tabela!";
                    }

                    ?>
                        
                        <div class="cardName">Solicitações Pendentes</div>
                    </div>

                    <div class="iconBx">
                    <ion-icon name="warning-outline"></ion-icon>
                    </div>
                </div>

                <!-- fim segundo card -->
                
            <div class="card">
                    <div>
            <?php

                include_once("conexao.php");

                $count = "SELECT COUNT( cod_soli) AS total from solicitacao WHERE status_soli='Reprovado'";

                $qtd = $conexao->query($count);

                if($qtd -> num_rows >0){

                    $objeto = $qtd ->fetch_assoc();
                    echo "<div class='numbers'>";
                    echo $objeto["total"];
                    echo"</div>";


                }else{
                    echo"Nenhum registro encontrado na tabela!";
                }

            ?>
                        <div class="cardName">Solicitações Reprovadas</div>
                    </div>

                    <div class="iconBx">
                    <ion-icon name="close-outline"></ion-icon>
                    </div>
                </div>

                <!-- fim terceiro card -->

                <div class="card">
                    <div>
                    <?php

                    include_once("conexao.php");

                    $count = "SELECT COUNT( cod_soli) AS total from solicitacao WHERE status_soli='Aprovado'";

                    $qtd = $conexao->query($count);

                    if($qtd -> num_rows >0){

                        $objeto = $qtd ->fetch_assoc();
                        echo "<div class='numbers'>";
                        echo $objeto["total"];
                        echo"</div>";


                    }else{
                        echo"Nenhum registro encontrado na tabela!";
                    }

                    ?>
                        <div class="cardName">Solicitações Aprovadas</div>
                    </div>

                    <div class="iconBx">
                    <ion-icon name="checkmark-outline"></ion-icon>
                    </div>
                </div>
            </div>
    

           
<?php

include_once("conexao.php");


if ($_SERVER["REQUEST_METHOD"] == "POST") {

$placa=$_POST['placa'];

$sql = "SELECT cod_soli,valor_soli,descricao_soli,status_soli, solicitacao.cod_veiculo AS codigo_veiculo, 
        DATE_FORMAT(data_soli,'%d/%m/%Y') AS data_soli,marca_veiculo,placa_veiculo
        FROM solicitacao
        INNER JOIN cad_veiculos ON cad_veiculos.cod_veiculo = solicitacao.cod_veiculo
        WHERE solicitacao.cod_veiculo='$placa'";




$result = $conexao->query($sql);

if ($result->num_rows > 0) {

   
    // Cria a tabela HTML
   // Cria a tabela HTML
        echo "<table border='1' id='minhaTabela' class='table'>";
        echo "<tr>";
        echo "<th>Cod Solicitação</th>";
        echo "<th>Valor</th>";
        echo "<th>Descrição</th>";
        echo "<th>Status</th>";
        echo "<th>Data</th>";
        echo "<th>Marca do Veículo</th>";
        echo "<th>Placa do Veículo</th>";
        echo "<th>PDF Download</th>";
        echo "<th>Responder Solicitação</th>";
        echo "</tr>";

// Exibe os dados em cada linha da tabela
while($row = $result->fetch_assoc()) {
    $codigo_veiculo = $row["codigo_veiculo"];
    $status = $row["status_soli"];

    if($status == 'Pendente'){

        echo "<tr class='pendente'>";

    }else if($status =='Aprovado'){
        echo "<tr class='aprovado'>";
    }else if($status == 'Reprovado'){
        echo "<tr class='reprovado'>";
    }
   

   
    echo "<td>" . $row["cod_soli"] . "</td>";
    echo "<td>" . $row["valor_soli"] . "</td>";
    echo "<td>" . $row["descricao_soli"] . "</td>";
    echo "<td>" . $row["status_soli"] . "</td>";
    echo "<td>" . $row["data_soli"] . "</td>";
    echo "<td>" . $row["marca_veiculo"] . "</td>";
    echo "<td>" . $row["placa_veiculo"] . "</td>";
    echo "<td>";

    echo "<form id='download_form_" . $row["cod_soli"] . "' action='download_pdf.php' method='post' style='display:inline;'>";
    echo "<input type='hidden' name='id' value='" . $row["cod_soli"] . "'>";
    echo "<a href='#' onclick='document.getElementById(\"download_form_" . $row["cod_soli"] . "\").submit(); return false;'>Baixar PDF</a>";
    echo "</form>";
    echo "</td>";
    echo "<td>";

    echo "<form id='form_" . $row["cod_soli"] . "' action='processo_resposta.php' method='post' style='display:inline;'>";

    echo "<input type='hidden' name='id' value='" . $row["cod_soli"] . "'>";
    echo "<input type='hidden' name='codigo_veiculo' value='" . $row["codigo_veiculo"] . "'>";
    echo "<select name='resposta'>";
    echo "<option value='Aprovado'>Aprovado</option>";
    echo "<option value='Reprovado'>Reprovado</option>";
    echo "</select>";
    echo "<input type='submit' onclick ='changeColor()' value='Enviar'>";
   
    echo"<script src='../JAVA/mudarCor'></script>";

    echo "</form>";
    echo "</td>";

    echo "</tr>";
}

echo "</table>";


}
}
?>

</body>
</html>
