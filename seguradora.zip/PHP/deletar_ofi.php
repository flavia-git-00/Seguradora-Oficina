<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        /* Estilo para centralizar o indicador de carregamento */
        .loading-container {
          background-image: linear-gradient(to right, rgb(30, 20, 32),#551252);
            display: flex;
            justify-content: center;
            align-items: center;
            position: fixed;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: black;
            z-index: 9999;
        }

        .loading-container img {
            border-radius:15px;
            width:600px;
            height: 400px;
        }
    </style>
</head>
<body>


<?php

  include_once('conexao.php');

        $oficina = '';

        if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $oficina = $_POST['oficina'];

        $query = "DELETE FROM cad_oficina WHERE cod_usuario_oficina = '$oficina'";
        
        if (mysqli_query($conexao, $query)) {
          echo '<div class="loading-container">';
          echo '<img src="../GIF/DELETAROFI.gif" alt="Carregando...">';
          echo '</div>';

          echo '<div id="content" style="display:none;">';

          // Senha correta, redireciona para a página desejada
          echo '<script type="text/javascript">';
          echo 'document.getElementById("content").style.display = "block";'; // Exibe o conteúdo principal
          echo 'setTimeout(function() { window.location.href = "../PHP/deletar.php"; }, 6000);'; // Redireciona após 6 segundos
          echo '</script>';
      } else {
          echo '<script>';
          echo 'alert("[ERRO!] AO TENTAR DELETAR OFICINA! (TENTE NOVAMENTE!) ' . mysqli_error($conexao) . '");';
          echo 'window.location.href = "../HTML/carros.html";'; // Redirecionamento em JavaScript
          echo '</script>';
      }
    
    }

        
  
?>
