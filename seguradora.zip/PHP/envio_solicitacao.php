<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        /* Estilo para centralizar o indicador de carregamento */
        .loading-container {
            background-image: linear-gradient(to right, rgb(30, 20, 32), #551252, rgb(30, 20, 32));
            display: flex;
            justify-content: center;
            align-items: center;
            position: fixed;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: black;
            z-index: 9999;
        }

        .loading-container img {
            border-radius:15px;
            width:600px;
            height: 400px;
        }
    </style>
</head>
<body>

<?php

include_once("conexao.php");


     $valor = $_POST['valor'];
     $descricao = $_POST['descricao'];
     $pdf = $_FILES['pdf']['tmp_name'];
     $tamanho = $_FILES['pdf']['size'];
     $tipo = $_FILES['pdf']['type'];
     $nome = $_FILES['pdf']['name'];
     $codigo_veiculo = $_POST['codigo_veiculo'];
  

    if($pdf != "none"){
    $fp = fopen($pdf,"rb");
    $conteudo = fread($fp,$tamanho);
    $conteudo = addslashes($conteudo);
    fclose($fp);
    } 
    

    
$inserir = "
INSERT INTO solicitacao (cod_veiculo, valor_soli, descricao_soli, pdf_nome, pdf_tipo, pdf_tamanho, pdf)
SELECT '$codigo_veiculo', '$valor', '$descricao', '$nome', '$tipo', '$tamanho', '$conteudo'
FROM cad_veiculos
WHERE cad_veiculos.cod_veiculo = '$codigo_veiculo'
";

// Exibe a consulta para verificar se está correta


if (mysqli_query($conexao, $inserir)) {
    echo '<div class="loading-container">';
    echo '<img src="../GIF/solicitacao.gif" alt="Carregando...">';
    echo '</div>';

    echo '<div id="content" style="display:none;">';
    
    // Senha correta, redireciona para a página desejada
    echo '<script type="text/javascript">';
    echo 'document.getElementById("content").style.display = "block";'; // Exibe o conteúdo principal
    echo 'setTimeout(function() { window.location.href = "solicitacao.php"; }, 6000);'; // Redireciona após 3 segundos
    echo '</script>';
} else {

    echo '<script>';
    echo 'alert("[ERRO!] Você não pode solicitar seguro no mesmo veículo' . mysqli_error($conexao) . '");';
    echo 'window.location.href = "../PHP/solicitacao.php";'; // Redirecionamento em JavaScript
    echo '</script>';
    exit();
}
?>
             
</body>
</html>