<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado do Cadastro</title>
    <style>
        /* Estilo para centralizar o indicador de carregamento */
        .loading-container {
            display: flex;
            justify-content: center;
            align-items: center;
            position: fixed;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: black;
            z-index: 9999;
        }

        .loading-container img {
            width: 500px;
            height: 400px;
        }
    </style>
</head>
<body>
<!-- Indicador de carregamento -->
<div class="loading-container" id="loading">
    <img src="../IMG/carregar.gif" alt="Carregando...">
</div>

<?php
include_once("conexao.php");

$nome = $_POST['nome'];
$cnpj = $_POST['cnpj'];
$contato = $_POST['telefone'];
$usuario = $_POST['admin'];
$senha = $_POST['senha'];
$confirmSenha = $_POST['confirmsenhaOfi'];
$email = $_POST['email'];


// Exibe o indicador de carregamento enquanto o cadastro está sendo processado


// Insere os dados no banco de dados



if ($senha !== $confirmSenha) {
    echo '<script type="text/javascript">';
    echo 'alert("As senhas não estão iguais!!!");';
    echo 'location.replace("../HTML/cadastrar_oficina.html");';
    echo '</script>';
} else {
    $insere = mysqli_query($conexao, "INSERT INTO cad_oficina (cad_nome,cad_gmail,cad_cnpj, cad_telefone, cad_adm, cad_senha)
    VALUES ('$nome', '$email','$cnpj', '$contato','$usuario','$senha')") or die(mysqli_error($conexao));
    // Escondendo o indicador de carregamento após a conclusão do processo
    echo '<script type="text/javascript">';
    echo 'setTimeout(function() { window.location.href = "../HTML/login_ofi.html"; }, 3000);'; // Redireciona após 3 segundos
    echo '</script>';
}
?>
</body>
</html>

