<?php
// Conexão com o banco de dados
include_once('conexao.php');

// Verifica se o formulário foi submetido e se o parâmetro foi definido
if(isset($_POST['deletar_imagem']) && isset($_POST['codigo_imagem_chassi'])) {
    // Obtém o valor selecionado do select
    $codigo_imagem = $_POST['codigo_imagem_chassi'];
    
    // Query de exclusão
    $query = "DELETE FROM imagens WHERE cod_imagem = '$codigo_imagem'";
    
    // Executa a query
    if(mysqli_query($conexao, $query)) {
        echo '<script>';
        echo 'alert("IMAGEM CHASSI DELETADA COM SUCESSO!");';
        echo 'window.location.href = "../PHP/selectimg.php";'; // Redirecionamento em JavaScript
        echo '</script>';
    } else {
        echo "Erro ao deletar imagem: " . mysqli_error($conexao);
    }
}

 if(isset($_POST['deletar_imagem']) && isset($_POST['codigo_hodometro'])) {

 $codigo_imagem_H= $_POST['codigo_hodometro'];
 $query_H = "DELETE FROM imagens_hodometro WHERE cod_imagem_hodometro = '$codigo_imagem_H'";

 if(mysqli_query($conexao, $query_H)) {
        echo '<script>';
        echo 'alert("IMAGEM HÔDOMETRO DELETADA COM SUCESSO!");';
        echo 'window.location.href = "../PHP/selectimg.php";'; // Redirecionamento em JavaScript
        echo '</script>';
} else {
    echo "Erro ao deletar imagem: " . mysqli_error($conexao);
}

}

if(isset($_POST['deletar_imagem']) && isset($_POST['codigo_frente'])) {

    $codigo_imagem_F= $_POST['codigo_frente'];
    $query_F = "DELETE FROM imagens_frente WHERE cod_imagem_frente = '$codigo_imagem_F'";
   
    if(mysqli_query($conexao, $query_F)) {
        echo '<script>';
        echo 'alert("IMAGEM FRENTE DELETADA COM SUCESSO!");';
        echo 'window.location.href = "../PHP/selectimg.php";'; // Redirecionamento em JavaScript
        echo '</script>';
   } else {
       echo "Erro ao deletar imagem: " . mysqli_error($conexao);
   }
   
   }

   if(isset($_POST['deletar_imagem']) && isset($_POST['codigo_traseira'])) {

    $codigo_imagem_T= $_POST['codigo_traseira'];
    $query_T = "DELETE FROM imagens_traseira WHERE cod_imagem_traseira = '$codigo_imagem_T'";
   
    if(mysqli_query($conexao, $query_T)) {
        echo '<script>';
        echo 'alert("IMAGEM TRASEIRA DELETADA COM SUCESSO!");';
        echo 'window.location.href = "../PHP/selectimg.php";'; // Redirecionamento em JavaScript
        echo '</script>';
   } else {
       echo "Erro ao deletar imagem: " . mysqli_error($conexao);
   }
   
   }

   if(isset($_POST['deletar_imagem']) && isset($_POST['codigo_latdireita'])) {

    $codigo_imagem_LD= $_POST['codigo_latdireita'];
    $query_LD = "DELETE FROM imagens_latdireita WHERE cod_imagem_latdireita = '$codigo_imagem_LD'";
   
    if(mysqli_query($conexao, $query_LD)) {
        echo '<script>';
        echo 'alert("IMAGEM LATERAL DIREITA DELETADA COM SUCESSO!");';
        echo 'window.location.href = "../PHP/selectimg.php";'; // Redirecionamento em JavaScript
        echo '</script>';
   } else {
       echo "Erro ao deletar imagem: " . mysqli_error($conexao);
   }
   
   }

   if(isset($_POST['deletar_imagem']) && isset($_POST['codigo_latesquerda'])) {

    $codigo_imagem_LE= $_POST['codigo_latesquerda'];
    $query_LE = "DELETE FROM imagens_latesquerda WHERE cod_imagem_latesquerda = '$codigo_imagem_LE'";
   
    if(mysqli_query($conexao, $query_LE)) {
        echo '<script>';
        echo 'alert("IMAGEM LATERAL ESQUERDA DELETADA COM SUCESSO!");';
        echo 'window.location.href = "../PHP/selectimg.php";'; // Redirecionamento em JavaScript
        echo '</script>';
   } else {
       echo "Erro ao deletar imagem: " . mysqli_error($conexao);
   }
   
   }

   if(isset($_POST['deletar_imagem']) && isset($_POST['codigo_capo'])) {

    $codigo_imagem_C= $_POST['codigo_capo'];
    $query_C = "DELETE FROM imagens_capo WHERE cod_imagem_capo = '$codigo_imagem_C'";
   
    if(mysqli_query($conexao, $query_C)) {
        echo '<script>';
        echo 'alert("IMAGEM CAPÔ DELETADA COM SUCESSO!");';
        echo 'window.location.href = "../PHP/selectimg.php";'; // Redirecionamento em JavaScript
        echo '</script>';
   } else {
       echo "Erro ao deletar imagem: " . mysqli_error($conexao);
   }
   
   }

   if(isset($_POST['deletar_imagem']) && isset($_POST['codigo_pecas'])) {

    $codigo_imagem_P= $_POST['codigo_pecas'];
    $query_P = "DELETE FROM imagens_pecas WHERE cod_imagem_pecas = '$codigo_imagem_P'";
   
    if(mysqli_query($conexao, $query_P)) {
        echo '<script>';
        echo 'alert("IMAGEM PEÇA DELETADA COM SUCESSO!");';
        echo 'window.location.href = "../PHP/selectimg.php";'; // Redirecionamento em JavaScript
        echo '</script>';
   } else {
       echo "Erro ao deletar imagem: " . mysqli_error($conexao);
   }
   
   }


?>
