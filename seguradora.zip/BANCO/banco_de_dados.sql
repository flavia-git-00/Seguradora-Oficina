CREATE DATABASE seguradora;

 CREATE TABLE login_seg (
    
	    cod_usuario int primary key AUTO_INCREMENT,
        cad_nome_seg varchar(50),
        cad_adm varchar(50),
        cad_usuario varchar (12),
        cad_senha varchar(12)

    ); 
 CREATE TABLE cad_oficina(
	cod_usuario_oficina int primary key AUTO_INCREMENT,
    cad_nome varchar(50),
    cad_gmail varchar(64),
    cad_cnpj char(18),
	cad_telefone varchar(20),
	cad_adm varchar(50),
    cad_senha varchar(12)

    );

 CREATE TABLE cad_veiculos (
	cod_veiculo int primary key AUTO_INCREMENT,
	marca_veiculo varchar(60),
	modelo_veiculo varchar(60),
	ano_veiculo char(4),
    cor_veiculo varchar(30),
	placa_veiculo char(7),
	hodometro_veiculo varchar(13),
	chassi_veiculo char(17)
    );
	
CREATE TABLE IF NOT EXISTS imagens (
    cod_imagem int(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome_imagem varchar(25) NOT NULL,
    tamanho_imagem varchar(25) NOT NULL,
    tipo_imagem varchar(25) NOT NULL,
    imagem longblob NOT NULL,
    cod_veiculo int,
    FOREIGN KEY (cod_veiculo) REFERENCES cad_veiculos (cod_veiculo) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS imagens_hodometro (
    cod_imagem_hodometro int(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome_imagem_hodometro varchar(25) NOT NULL,
    tamanho_imagem_hodometro varchar(25) NOT NULL,
    tipo_imagem_hodometro varchar(25) NOT NULL,
    imagem_hodometro longblob NOT NULL,
    cod_veiculo int,
    FOREIGN KEY (cod_veiculo) REFERENCES cad_veiculos (cod_veiculo) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS imagens_frente (
    cod_imagem_frente int(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome_imagem_frente varchar(25) NOT NULL,
    tamanho_imagem_frente varchar(25) NOT NULL,
    tipo_imagem_frente varchar(25) NOT NULL,
    imagem_frente longblob NOT NULL,
    cod_veiculo int,
    FOREIGN KEY (cod_veiculo) REFERENCES cad_veiculos (cod_veiculo) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS imagens_traseira (
    cod_imagem_traseira int(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome_imagem_traseira varchar(25) NOT NULL,
    tamanho_imagem_traseira varchar(25) NOT NULL,
    tipo_imagem_traseira varchar(25) NOT NULL,
    imagem_traseira longblob NOT NULL,
    cod_veiculo int,
    FOREIGN KEY (cod_veiculo) REFERENCES cad_veiculos (cod_veiculo) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
 
 CREATE TABLE IF NOT EXISTS imagens_latesquerda (
    cod_imagem_latesquerda int(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome_imagem_latesquerda varchar(25) NOT NULL,
    tamanho_imagem_latesquerda varchar(25) NOT NULL,
    tipo_imagem_latesquerda varchar(25) NOT NULL,
    imagem_latesquerda longblob NOT NULL,
    cod_veiculo int,
    FOREIGN KEY (cod_veiculo) REFERENCES cad_veiculos (cod_veiculo) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS imagens_latdireita (
    cod_imagem_latdireita int(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome_imagem_latdireita varchar(25) NOT NULL,
    tamanho_imagem_latdireita varchar(25) NOT NULL,
    tipo_imagem_latdireita varchar(25) NOT NULL,
    imagem_latdireita longblob NOT NULL,
    cod_veiculo int,
    FOREIGN KEY (cod_veiculo) REFERENCES cad_veiculos (cod_veiculo) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS imagens_capo (
    cod_imagem_capo int(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome_imagem_capo varchar(25) NOT NULL,
    tamanho_imagem_capo varchar(25) NOT NULL,
    tipo_imagem_capo varchar(25) NOT NULL,
    imagem_capo longblob NOT NULL,
    cod_veiculo int,
    FOREIGN KEY (cod_veiculo) REFERENCES cad_veiculos (cod_veiculo) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS imagens_pecas (
    cod_imagem_pecas int(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome_imagem_pecas varchar(25) NOT NULL,
    tamanho_imagem_pecas varchar(25) NOT NULL,
    tipo_imagem_pecas varchar(25) NOT NULL,
    imagem_pecas longblob NOT NULL,
    cod_veiculo int,
    FOREIGN KEY (cod_veiculo) REFERENCES cad_veiculos (cod_veiculo) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
 
CREATE TABLE solicitacao(
    cod_soli INT PRIMARY KEY AUTO_INCREMENT,
    valor_soli DECIMAL(10, 2) NOT NULL,
    descricao_soli TEXT NOT NULL,
    status_soli VARCHAR(50) DEFAULT 'Pendente',
    data_soli DATE NOT NULL DEFAULT CURRENT_DATE,
    pdf_nome VARCHAR(255) NOT NULL,
    pdf_tipo VARCHAR(255) NOT NULL,
    pdf_tamanho INT NOT NULL,
    pdf LONGBLOB NOT NULL,
    cod_veiculo INT,
    FOREIGN KEY (cod_veiculo) REFERENCES cad_veiculos (cod_veiculo) ON DELETE CASCADE,
    CONSTRAINT unique_solicitacao_veiculo_data UNIQUE (cod_veiculo, data_soli)
);

CREATE TABLE resposta (
    cod_res INT PRIMARY KEY AUTO_INCREMENT,
    resposta TEXT,
    data_res DATE NOT NULL DEFAULT CURRENT_DATE,
    cod_veiculo INT,
    cod_soli INT,
    FOREIGN KEY (cod_veiculo) REFERENCES cad_veiculos(cod_veiculo) ON DELETE CASCADE,
    FOREIGN KEY (cod_soli) REFERENCES solicitacao(cod_soli) ON DELETE CASCADE,
    CONSTRAINT unique_resposta_veiculo_solicitacao_data UNIQUE (cod_veiculo, cod_soli, data_res)
);





